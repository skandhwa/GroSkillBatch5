package InheritanceExamples;

class B4
{
	
	void display()
	{
		System.out.println("I am B1 method");
	}
}
class B2 extends B4
{
	
	void display()
	{
		System.out.println("Hello");
		
	}
	
	void shape()
	{
		System.out.println("Java");
	}
}

class B3 extends B2
{
	void test()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		System.out.println("Hey");
	}
	
	void display()
	{
		System.out.println("how r u");
	}
	
	void run()
	{
		test();
		message();
		display();
		shape();
		super.display();
		
		
	}
}





public class SuperforMethods {

	public static void main(String[] args) {
		
		B3 obj=new B3();
		obj.run();
		

	}

}
