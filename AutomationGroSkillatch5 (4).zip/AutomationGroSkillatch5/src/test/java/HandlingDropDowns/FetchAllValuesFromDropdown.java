package HandlingDropDowns;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FetchAllValuesFromDropdown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
        
        driver.get("https://demo.automationtesting.in/Register.html");
        driver.manage().window().maximize();
        WebElement ele=  driver.findElement(By.id("Skills"));
        if(ele.isDisplayed()==true && ele.isEnabled()==true)
        {
        	Select oselect=new Select(ele);
        	
        	
        List<WebElement> li=	oselect.getOptions();
        int x=li.size();
        System.out.println("Total no of values in dropdown is  "+x);
        for(int i=0;i<li.size();i++)
        {
        	String value=   li.get(i).getText();
        	System.out.println(value);
        	
        	if(value.equalsIgnoreCase("Android"))
        	{
        	System.out.println("My element found ,,,, exiting the code");
        	break;
        	}
        	
        	
        	
        	
        	
        }
        
        
        	
        	
        	
        }
	}

}
