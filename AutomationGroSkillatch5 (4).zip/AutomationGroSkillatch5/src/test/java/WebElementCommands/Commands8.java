package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Commands8 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///E:/Practice%20Form23rd%20Jan.html");
		 driver.manage().window().maximize();
 WebElement ele=driver.findElement(By.xpath("//button[@id='submitBtn']"));
 
 Point p=ele.getLocation();
 System.out.println("Location of element is web page is  "+p.x+"  "+p.y);
 
String value2=ele.getCssValue("input");
 System.out.println(value2);
 
Dimension d=ele.getSize();
 System.out.println("Height and width of element is   "+d.height+"  "+d.width);
 
 
 if(ele.isDisplayed()==true && ele.isEnabled()==true)
 {
	String value=  ele.getText();
	System.out.println(value);
	
	String attValue=ele.getAttribute("type");
	System.out.println("Attribute value is  "+attValue);
 }
 
  String tagName=  driver.findElement(By.id("username")).getTagName();
 System.out.println(tagName);
 
 
 
 
 
 
 
 
		

	}

}
