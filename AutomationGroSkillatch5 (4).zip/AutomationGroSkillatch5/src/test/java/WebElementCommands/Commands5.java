package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Commands5 {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		Thread.sleep(3000);
		
	WebElement ele=	driver.findElement(By.xpath("//input[@id='checkbox1']"));
	
	if(ele.isSelected()==true)
	{
		System.out.println("Element is already selected on webpage");
		
	}
	
	else
	{
		System.out.println("Element not selected , selecting the element");
		ele.click();
	}
	

	}

}
