package ConditionalStatements;

public class ifElseLadder {

	public static void main(String[] args) {
		
		int a=20;
		int b=15;
		int c=25;
		int d=45;
		int e=56;
		
		if(a>b && a>c && a>d && a>e)
		{
			System.out.println("a is maximum");
		}
		
		else if(b>a && b>c && b>d && b>e )
		{
			System.out.println("b is maximum");
		}
		
		else if(c>a && c>b && c>d  && c>e )
		{
			System.out.println("c is maximum");
		}
		
		else if(d>a && d>b && d>c  && d>e )
		{
			System.out.println("d is maximum");
		}
		
		else
		{
			System.out.println(" e is maximum");
		}

	}

}
