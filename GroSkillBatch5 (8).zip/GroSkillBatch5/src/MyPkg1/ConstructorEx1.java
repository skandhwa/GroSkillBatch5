package MyPkg1;

class A9
{
//	A9()
//	{
//		System.out.println("Hi");
//	}
//	
	
	
	void display()
	{
		System.out.println("Hello");
	}
}



public class ConstructorEx1 {

	public static void main(String[] args) {
		
		A9 obj=new A9();
		obj.display();
		
		
		

	}

}
