package PolymorphismEx;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
	void display()
	{
		System.out.println("Hello");
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
	void display()
	{
		getROI(6,5);
		super.getROI(4, 7);
	}
	
}

class Axis extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}



public class MethodOverridingEx1 {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
		obj.getROI(3, 4);
		
		Axis obj1=new Axis();
		obj1.getROI(5, 7);
		obj1.display();

	}

}
