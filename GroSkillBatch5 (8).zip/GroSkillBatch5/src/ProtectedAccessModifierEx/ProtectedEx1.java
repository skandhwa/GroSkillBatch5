package ProtectedAccessModifierEx;

class Test2
{
	protected int x=5;
	protected void run()
	{
		System.out.println("Hi");
	}
}

public class ProtectedEx1 
{
	
	protected void display()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		ProtectedEx1 obj=new ProtectedEx1();
		obj.display();
		
		Test2 obj1=new Test2();
		obj1.run();
		
		

	}

}
