package PublicEx2;

import PublicEx1.MyClass1;

public class MyClass3 {

	public static  void main(String[] args) {
		
		MyClass1 obj=new MyClass1();
		obj.display();
		

	}

}
