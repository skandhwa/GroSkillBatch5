package PublicEx1;

public class MyClass1 {
	
	public void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		MyClass1 obj=new MyClass1();
		obj.display();
		

	}

}
