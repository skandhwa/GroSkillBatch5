package ProtectedAccessModifier2;
//import ProtectedAccessModifierEx.ProtectedEx1;

import ProtectedAccessModifierEx.ProtectedEx1;

public class ProtectedEx3 extends ProtectedEx1 {

	public static void main(String[] args) {
		
		ProtectedEx3 obj=new ProtectedEx3();
		obj.display();
		
		

	}

}
