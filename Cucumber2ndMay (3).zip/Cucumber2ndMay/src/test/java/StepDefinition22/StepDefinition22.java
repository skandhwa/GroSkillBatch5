package StepDefinition22;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition22 {
	
	WebDriver driver;
	
	@Before
	public void beforeTest()
	{
		System.out.println("This is before test");
	}
	
	@After
	public void AfterTest()
	{
		System.out.println("This is after test");
	}
	
	@Before("@sanity")
	public void beforeSanity()
	{
		System.out.println("This is before sanity");
	}
	
	@After("@sanity")
	public void afterSanity()
	{
		System.out.println("This is after sanity");
	}
	
	@Before("@smoke")
	public void beforeSmoke()
	{
		System.out.println("This is before smoke");
	}
	
	@After("@smoke")
	public void afterSmoke()
	{
		System.out.println("This is after smoke");
	}
	
	
	
	@Given("user opens the browser url of facebook")
	public void user_opens_the_browser_url_of_facebook() {
	    
		System.out.println("Fb login page opened");
		
	}

	@Given("user enters the username")
	public void user_enters_the_username() {
		
		System.out.println("User Id enetered");
		
	   
	}

	@Given("user enters the password")
	public void user_enters_the_password() {
	    
		System.out.println("password enetered");
	}

	@When("user clicks on login button of facebook")
	public void user_clicks_on_login_button_of_facebook() {
		
		System.out.println("Login button clicked");
	    
	}

	@Then("user lands into the HomePage of the application")
	public void user_lands_into_the_home_page_of_the_application() {
		
		System.out.println("Navigated to homepage");
	    
	}
	
	
	@When("the entered credentials are wrong")
	public void the_entered_credentials_are_wrong() {
	    
		System.out.println("Enetered credentials are wrong");
	}

	@Then("an error message will be displayed on the loginpage")
	public void an_error_message_will_be_displayed_on_the_loginpage() {
		
		System.out.println("Error thrown on webpage");
	    
	}
	
	
	@Given("user enters the username for facebook as {string}")
	public void user_enters_the_username_for_facebook_as(String username) {
	   
		System.out.println("parameterized username enetered");
		
	}

	@Given("user enters the password for facebook as {string}")
	public void user_enters_the_password_for_facebook_as(String password) {
	   
		System.out.println("parameterized password enetered");
	}
	
	@Given("user opens the browser url of amazon")
	public void user_opens_the_browser_url_of_amazon() {
		System.out.println("amazon login page opened");
	}

	@Given("user enters the username for amazon as {string}")
	public void user_enters_the_username_for_amazon_as(String string) {
	    
		System.out.println("username enetered");
	}

	@Given("user enters the password for amazon as {string}")
	public void user_enters_the_password_for_amazon_as(String string) {
	   
		System.out.println("password enetered");
	}

	@When("user clicks on login button of amazon")
	public void user_clicks_on_login_button_of_amazon() {
		
		System.out.println("login button clicked");
	   
	}

	@Then("user will be navigated to amazon homepage")
	public void user_will_be_navigated_to_amazon_homepage() {
	   
		System.out.println("navigated to homepage");
	}

	@Then("user enters product as {string} in search box")
	public void user_enters_product_as_in_search_box(String string) {
	    
		System.out.println("product serahced");
	}

	@Then("user hits enter button")
	public void user_hits_enter_button() {
		
		System.out.println("eneter clicked");
	  
	}

	@Then("all list of {string} is displayed")
	public void all_list_of_is_displayed(String string) {
		
		System.out.println("product displayed");
	    
	}

	
	@Then("user searches reebok shoe and add that to cart")
	public void user_searches_reebok_shoe_and_add_that_to_cart() {
	   
		System.out.println("user searches reebok shoes");
		
	}

	@Then("user searches titan watch and add that to cart")
	public void user_searches_titan_watch_and_add_that_to_cart() {
	   
		System.out.println("user searches titan watch");
	}

	@Then("user searches apple iphone and add that to cart")
	public void user_searches_apple_iphone_and_add_that_to_cart() {
		
		System.out.println("user searches iphone ");
		
	    
	}

	@Then("user searches puma tshirt and add that to cart")
	public void user_searches_puma_tshirt_and_add_that_to_cart() {
	   
		System.out.println("user searches tshirts");
	}

	@Then("user removes one product and now count of product is {int}")
	public void user_removes_one_product_and_now_count_of_product_is(Integer int1) {
	    
		System.out.println("validate count as 2");
	}

	@Then("user removes one more product and now count of product is {int}")
	public void user_removes_one_more_product_and_now_count_of_product_is(Integer int1) {
	    
		System.out.println("validate count as 1");
	}

	

@Given("user logins into guru99 demo page")
public void user_logins_into_guru99_demo_page() {
	
	driver.get("https://demo.automationtesting.in/Register.html");
	driver.manage().window().maximize();
	
    
}

@Given("user enters the below details in format")
public void user_enters_the_below_details_in_format(io.cucumber.datatable.DataTable userData) {
    
	     
	
	     List<List<String>>li=userData.asLists(String.class);
	     driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(li.get(1).get(0));
	     driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(li.get(1).get(1));
	     driver.findElement(By.xpath("//textarea[@rows=3]")).sendKeys(li.get(1).get(2));
	     driver.findElement(By.xpath("//input[@type='email']")).sendKeys(li.get(1).get(3));
	     driver.findElement(By.xpath("//input[@type='tel']")).sendKeys(li.get(1).get(4));
	     
	
	
}


@Given("user open the guru99 demo page")
public void user_open_the_guru99_demo_page() {
	
	driver=new ChromeDriver();
	driver.get("https://demo.guru99.com/V4/index.php");
	driver.manage().window().maximize();
    
}

@Given("user enters the uname as {string} in given field")
public void user_enters_the_uname_as_in_given_field(String username) {
	
	driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(username);
    
}

@Given("user enters the pwd as {string} in given field")
public void user_enters_the_pwd_as_in_given_field(String password) {
	
	driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
   
}

@When("user clicks on the login button of demo page")
public void user_clicks_on_the_login_button_of_demo_page() throws InterruptedException {
	
	driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
	Thread.sleep(3000);
   
}

@Then("user navigates to home page of guru99")
public void user_navigates_to_home_page_of_guru99() throws AccountNotFoundException {
	
	String title=driver.getTitle();
	if(title.equalsIgnoreCase("Guru99 Bank Manager HomePage"))
	{
		System.out.println("Test case passed");
	}
	else
	{
		throw new AccountNotFoundException("Login in incorrect");
	}
	
	
	
    
}


@Then("user validates everything and logsout")
public void user_validates_everything_and_logsout() {
   
}





}
