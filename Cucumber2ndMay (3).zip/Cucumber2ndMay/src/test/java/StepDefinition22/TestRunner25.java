package StepDefinition22;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
(
		features ="src/test/java/FeatureFiles/",
		glue= {"StepDefinition22"},
		tags="@smoke45 and @sanity45",
		dryRun=false,
		
		plugin= {"pretty","html:target/HtmlReport/index.html"}
		
		
		
		
		
		
		)










public class TestRunner25 {

}
