Feature: Registration form fill up

  Scenario: User Fills up the registartion form
    Given user logins into guru99 demo page
    And user enters the below details in format
      | FirstName | LastName | Address  | EmailAddress   | Phone      |
      | Harry     | Dsouza   | NewDelhi | abcd@.com | 9800765432 |

     