Feature: User Fills up the registration form


  Scenario Outline: Validate creation of new user
    Given user open the guru99 demo page
    And user enters the uname as "<username>" in given field
    And user enters the pwd as "<password>" in given field
    When user clicks on the login button of demo page
    Then user navigates to home page of guru99

    Examples: 
      | username   | password |
      | mngr662652 | urupYbA  |
