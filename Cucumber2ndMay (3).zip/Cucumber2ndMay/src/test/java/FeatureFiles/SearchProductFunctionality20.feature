Feature: Validate SP functionality

@smoke45 @sanity45
  Scenario Outline: Validate login functionality with correct credentials
    Given user opens the browser url of amazon
    And user enters the username for amazon as "<username>"
    
    
    And user enters the password for amazon as "<password>"
    When user clicks on login button of amazon
    Then user will be navigated to amazon homepage
    And user enters product as "<product>" in search box
    And user hits enter button
    Then all list of "<product>" is displayed
    Then user validates everything and logsout  
    
    

    Examples: 
      | username | password  | product |
      | test123  | test@1234 | shoes   |
