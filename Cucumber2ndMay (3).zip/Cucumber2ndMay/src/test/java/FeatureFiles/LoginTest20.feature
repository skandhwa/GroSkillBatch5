Feature: Validate Login functionality

  @smoke23
  Scenario: Validate login functionality with correct credentials
    Given user opens the browser url of facebook
    And user enters the username
    And user enters the password
    When user clicks on login button of facebook
    Then user lands into the HomePage of the application

  @sanity
  Scenario: Validate login functionality with incorrect credentials
    Given user opens the browser url of facebook
    And user enters the username
    And user enters the password
    When user clicks on login button of facebook
    But the entered credentials are wrong
    Then an error message will be displayed on the loginpage

  Scenario Outline: Validate login functionality with incorrect credentials
    Given user opens the browser url of facebook
    And user enters the username for facebook as "<username>"
    And user enters the password for facebook as "<password>"
    When user clicks on login button of facebook
    But the entered credentials are wrong
    Then an error message will be displayed on the loginpage

    Examples: 
      | username | password  |
      | test123  | test@1234 |
      | test456  | test@456  |
      | test789  | test@789  |
