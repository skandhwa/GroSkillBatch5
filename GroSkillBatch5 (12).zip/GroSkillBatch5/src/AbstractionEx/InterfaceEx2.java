package AbstractionEx;

interface I3
{
	void display();
	void test();
}

interface I4
{
	void show();
	void run();
}

class E10 implements I3,I4
{
	public void display()
	{
		System.out.println("Hello");
	}
	public void test()
	{
		System.out.println("Hi");
	}
	
	public void show()
	{
		System.out.println("Java");
	}
	
	public void run()
	{
		System.out.println("Programming");
	}
	
}




public class InterfaceEx2 {

	public static void main(String[] args) {
		
		I3 ref=new E10();
		ref.display();
		ref.test();
		
		I4 ref1=new E10();
		ref1.show();
		ref1.run();
		
		

	}

}
