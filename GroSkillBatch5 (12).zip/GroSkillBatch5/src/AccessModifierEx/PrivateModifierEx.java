package AccessModifierEx;


public class PrivateModifierEx 
{
    private int x=10;     	
	private void display()
	{
		System.out.println("Hello");
	}

	public static void main(String[] args) {
		
		
		PrivateModifierEx obj=new PrivateModifierEx();
		obj.display();
		
		
		System.out.println(obj.x);
		
		

	}

}
