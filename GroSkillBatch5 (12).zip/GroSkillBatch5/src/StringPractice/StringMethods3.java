package StringPractice;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="Republic";
		
	str=	str.substring(3, 8);
		
		
		System.out.println(str);

	}

}
