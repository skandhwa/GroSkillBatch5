package StringPractice;

public class StringBufferReplace {

	public static void main(String[] args) {
		
		
		StringBuffer sb=new StringBuffer("Hello");
		sb.replace(1, 2, "Java");
		System.out.println(sb);
		
		
		StringBuffer sb1=new StringBuffer("Selenium");
		sb1.reverse();
		System.out.println(sb1);
		
		int x=sb1.capacity();
		System.out.println("The total capacity is  "+x);
		
		
		
		
	

	}

}
