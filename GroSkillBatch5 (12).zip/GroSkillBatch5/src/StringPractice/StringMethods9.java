package StringPractice;

public class StringMethods9 {

	public static void main(String[] args) {
		
	    int a=10;
	    
	    Integer x=a;
	    
	    String str=x.toString();
		

	}

}
