package StringPractice;

public class StringMethods11 {

	public static void main(String[] args) {
		
		String str="12java";
		
		String str1="1java";
		
	boolean flag=	str.equalsIgnoreCase(str1);
	
	System.out.println(flag);
		
	
	int x=str.compareTo(str1);
	
	System.out.println(x);
	
	

	}

}
