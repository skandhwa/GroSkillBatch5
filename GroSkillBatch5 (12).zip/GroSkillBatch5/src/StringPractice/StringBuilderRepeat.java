package StringPractice;

public class StringBuilderRepeat {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Java");
		String str="Hello";
		
		str=str.repeat(6);
		System.out.println(str);
		
		
		
		

	}

}
