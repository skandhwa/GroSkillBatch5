package ConditionalStatements;

public class NestedIfBlock {

	public static void main(String[] args) {
		
		int age=15;
		
		if(age>18)
		{
			System.out.println("You are elligible to vote");
			
			if(age>60)
			{
				System.out.println("A represenattive will come home to take vote");
				
				if(age>75)
				{
					System.out.println("You can cast online");
				}
				
			}
			
		}
		
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		

	}

}
