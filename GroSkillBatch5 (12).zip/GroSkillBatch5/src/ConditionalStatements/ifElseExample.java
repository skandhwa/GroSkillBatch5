package ConditionalStatements;

public class ifElseExample {

	public static void main(String[] args) {
		
		int a=20,b=30;
		
		
		if(a>b)
		{
			System.out.println("a is max");
		}
		
		else
		{
			System.out.println("b is max");
		}
		
		
		

	}

}
