package LoopingStatements;

public class Rough {

	public static void main(String[] args) {
		
	int a=0;
	
	int p=--a;
	
	int q=p;
	
	System.out.println(q);
	
	

	}

}
