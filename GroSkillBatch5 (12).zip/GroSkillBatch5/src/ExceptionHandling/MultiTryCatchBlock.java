package ExceptionHandling;

public class MultiTryCatchBlock {

	public static void main(String[] args) {
		
		try
		{
			
			
			Thread t=new Thread();
			t.setPriority(45);
		int a=30;
		int b=30/0;
		System.out.println(b);
		
		
		String str=null;
		int x=str.length();
		System.out.println("Length of string is  "+x);
		
		
		
		int n[]= {12,45,67,88};
		System.out.println(n[7]);
		
		
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with   "+e.getMessage());
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		
		
		catch(IllegalArgumentException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		int p=20,q=30;
		int r=p+q;
		System.out.println(r);
		

	}

}
