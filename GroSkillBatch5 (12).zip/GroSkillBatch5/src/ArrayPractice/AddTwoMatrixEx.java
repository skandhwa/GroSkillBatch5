package ArrayPractice;

public class AddTwoMatrixEx {

	public static void main(String[] args) {
		
        int [][]a={{1,2,3},{4,5,6},{7,8,9}};
		
		int x=a.length;
		
		System.out.println("Length of array is  "+x);
		
		for(int i=0;i<x;i++)//i=0,0<3
		{
			for(int j=0;j<x;j++)//j=0,0<3//j=1,1<3
			{
				System.out.print(a[i][j]+" ");//
			}
			
			System.out.println();
		}
		
		
int [][]b={{6,7,9},{2,7,3},{2,1,4}};
		
		int y=b.length;
		
		System.out.println("Length of array is  "+y);
		
		for(int i=0;i<y;i++)//i=0,0<3
		{
			for(int j=0;j<y;j++)//j=0,0<3//j=1,1<3
			{
				System.out.print(b[i][j]+" ");//
			}
			
			System.out.println();
		}
		
		int [][]sum= new int [x][y];
		
		
	for(int i=0;i<x;i++)
	{
		for(int j=0;j<y;j++)
		{
			sum[i][j]= a[i][j]+b[i][j];
		}
	}
	
	System.out.println();
	System.out.println("#################################################");
	System.out.println("Sum of two array is  ");
	
	for(int i=0;i<x;i++)//i=0,0<3
	{
		for(int j=0;j<y;j++)//j=0,0<3//j=1,1<3
		{
			System.out.print(sum[i][j]+" ");//
		}
		
		System.out.println();
	}
	
		
		
		
		
		
		
		
		

	}

}
