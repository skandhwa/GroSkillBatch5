package CSSSelectorEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebTable {

	public static void main(String[] args) throws InterruptedException {
		
		String stockname="TITAN";
		
		
		String xpath="//*[text()='"+stockname+"']//parent::td//following-sibling::td[2]";
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.nseindia.com/market-data/live-equity-market");
		 Thread.sleep(4000);
		driver.manage().window().maximize();
	
	String highValue=	 driver.findElement(By.xpath(xpath)).getText();
		
	System.out.println(highValue);

	}

}
