package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Commands6 {

	public static void main(String[] args) {

         WebDriver driver=new ChromeDriver();
         String value="";
         driver.get("https://demo.automationtesting.in/Register.html");
         driver.manage().window().maximize();
     WebElement ele=    driver.findElement(By.xpath("(//label[@class='col-md-3 col-xs-3 col-sm-3 control-label'])[1]"));
         if(ele.isDisplayed()==true && ele.isEnabled()==true)
         {
        	 value= ele.getText();
         }
         
         System.out.println("Value is  "+value);

	}

}
