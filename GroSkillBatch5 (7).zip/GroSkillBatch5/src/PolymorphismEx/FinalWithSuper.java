package PolymorphismEx;

class D15
{
	final void display()
	{
		System.out.println("Hello");
	}
}

class D16 extends D15
{
	void test()
	{
		System.out.println("Hi");
	}
	
	void display1()
	{
		System.out.println("How r u");
	}
	
	void run()
	{
		test();
		display1();
		display();
	}
}


public class FinalWithSuper {

	public static void main(String[] args) {
		

	}

}
