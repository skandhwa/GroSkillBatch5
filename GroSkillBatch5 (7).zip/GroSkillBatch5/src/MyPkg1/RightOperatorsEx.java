package MyPkg1;

public class RightOperatorsEx {

	public static void main(String[] args) {
		
		int a=48;
		
		System.out.println(a>>>3);  //// 
		

	}

}
