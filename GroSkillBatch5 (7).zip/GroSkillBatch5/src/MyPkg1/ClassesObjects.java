package MyPkg1;

class A5
{
	void display()
	{
		System.out.println("Hello");
	}
}


class D3
{
	void display()
	{
		System.out.println("Hey");
	}
}



public class ClassesObjects {
	
	void test()
	{
		System.out.println("Hi");
	}
	
	 void test1()
	{
		System.out.println("message");
	}
	
	

	public static void main(String[] args) {
		
		A5 obj=new A5();
		obj.display();
		
		ClassesObjects obj1=new ClassesObjects();
		obj1.test();
		obj1.test1();
		
		D3 obj2=new D3();
		obj2.display();
		
		
		
		
		
		
		

	}

}
