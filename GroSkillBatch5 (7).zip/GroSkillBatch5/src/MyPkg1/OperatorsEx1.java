package MyPkg1;

public class OperatorsEx1 {

	public static void main(String[] args) {
		
		int a=0; 
		
		int b=1;
		
		int c= a/b;
		
		System.out.println(c);
		

	}

}
