package AbstractionEx;

interface I6 
{
	void test();
	void display();
}

interface I7 extends I6
{
	void show();
	void run();
	
}


 class F3 implements I7
{
	
	public void test()
	{
		System.out.println("Hi");
	}
	
	public void display()
	{
		System.out.println("Hello");
	}
	
	public void show()
	{
		System.out.println("Java");
	}
	
	public void run()
	{
		System.out.println("Programming");
	}
}




public class InterfaceEx4 {

	public static void main(String[] args) {
		
		I7 ref=new F3();
		ref.display();
		ref.show();
		ref.run();
		ref.test();
		

	}

}
