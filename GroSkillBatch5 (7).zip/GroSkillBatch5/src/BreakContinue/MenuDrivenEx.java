package BreakContinue;

public class MenuDrivenEx {

	public static void main(String[] args) {
		
		int marks=80;
		
		switch(marks)
		{
		case:
		
		
		
		
		}
		
		
		

	}

}
