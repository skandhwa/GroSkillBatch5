package LoopingStatements;

public class StartPattern {

	public static void main(String[] args) {
		
		
		int n=4;
		
		int x= n-1;
		
		int str =1;
		
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=x;j++)
			{
				System.out.println(" ");
			}
			
			x--;
			
			for(int k=1;k<=str;k++)
			{
				System.out.print("*"+" ");
				
			}
			
			str=str+2;
			System.out.println();
			
		}

	}

}
