package MyPkg1;

class A7
{
	int sum()
	{
		int a=10;
		int b=20;
		int c=a+b;
		//System.out.println(c);
		return c;
		
	}
	
}



public class MethodsEx2 {

	public static void main(String[] args) {
		
		A7 obj=new A7();
		
	//System.out.println(obj.sum());	
		
		obj.sum();
		
		

	}

}
