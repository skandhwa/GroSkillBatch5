package MyPkg1;

public class ShiftOperator {

	public static void main(String[] args) {
		
		int a=17;
		
		System.out.println(a<<3); /// 
		

	}

}
