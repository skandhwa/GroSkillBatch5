package ThisKeyword;

class D5
{
	void display()
	{
		System.out.println("Hello");
		
	}
	
	void show()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		System.out.println("Java");
	}
	
	void run()
	{
		this.display();
		this.message();
		this.show();
	}
	
}

class D6 extends D5
{
	void test()
	{
		super.run();
	}
}





public class ThisEx3 {

	public static void main(String[] args) {
		
		D6 obj=new D6();
		obj.test();
		

	}

}
