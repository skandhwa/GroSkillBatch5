package PushkarCode;

public class childclass extends constructorwithinheritance{

	
	
	public childclass(String id, String Nme, String Sal, String empl) 
	{
		super(id, Nme, Sal, empl);
		
	}




	public void finalMethod() {
		methodToBeCalled();
		System.out.println("The Employer Name is "+ employer);
	}
	
}
