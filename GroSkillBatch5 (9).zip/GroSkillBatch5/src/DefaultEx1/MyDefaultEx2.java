package DefaultEx1;

public class MyDefaultEx2 {

	public static void main(String[] args) {
		
		MyDefault1 obj=new MyDefault1();
		obj.display();

	}

}
