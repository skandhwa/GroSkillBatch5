package DefaultEx1;

public class MyDefault1 {
	
	 void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		MyDefault1 obj=new MyDefault1();
		obj.display();
		

	}

}
