package AbstractionEx;

interface I5
{
	void show();
	void run();
	void test();
	int sum(int x,int y);
	//int sum(int x,int y,int z);
	
	
}

class F1 implements I5
{
	public void show()
	{
		System.out.println("Hello");
	}
	
	public void run()
	{
		System.out.println("Hi");
	}
	
	public void test()
	{
		System.out.println("Java");
	}
	
	public int sum(int x,int y)
	{
		return x+y;
	}
}

class F2 implements I5
{
	public void show()
	{
		System.out.println("Hello1");
	}
	public void run()
	{
		System.out.println("Hi1");
	}
	
	public void test()
	{
		System.out.println("Java1");
	}
	
	public int sum(int x,int y)
	{
		return x+y;
	}
}


public class InterfaceEx3 {

	public static void main(String[] args) {
		

	}

}
