package ProtectedAccessModifierEx;

public class Protectedex2 {

	public static void main(String[] args) {
		
		Test2 obj1=new Test2();
		obj1.run();
		
		

	}

}
