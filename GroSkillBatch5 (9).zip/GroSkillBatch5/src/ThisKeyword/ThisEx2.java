package ThisKeyword;

class D3
{
	int id;
	String name;
	float salary;
	boolean isMarried;
	
	D3(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	D3(int id,String name,float salary,boolean isMarried)
	{
		
		this(id,name,salary);
		this.isMarried=isMarried;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary+"  "+isMarried);
	}
	
	
}


public class ThisEx2 {

	public static void main(String[] args) {
		
		D3 obj=new D3(1234,"Tom",80000f);
		obj.display();
		
		D3 obj1=new D3(1234,"Tom",80000f,true);
		obj1.display();
		

	}

}
