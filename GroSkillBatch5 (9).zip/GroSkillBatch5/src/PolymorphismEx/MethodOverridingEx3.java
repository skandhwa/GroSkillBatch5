package PolymorphismEx;

class D11
{
	int id;
	String name;
	
	D11(int id)
	{
		this.id=id;
	}
	
	D11(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	void display()
	{
		System.out.println(id+"  "+name);
	}
	
}

class D12 extends D11
{

	D12(int id) 
	{
		super(id);
		
	}
	
	void display()
	{
		System.out.println(super.id);
		System.out.println(super.name);
	}
	
}





public class MethodOverridingEx3 {

	public static void main(String[] args) {
		

	}

}
