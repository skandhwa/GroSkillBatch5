package Java8Topics;

@FunctionalInterface
interface I3
{
	public int sum(int a,int b);
}


//class C3 implements I3
//{
//	public int sum(int a,int b)
//	{
//		return a+b;
//	}
//}




public class UsingLambdaExpression {

	public static void main(String[] args) {
		
		
		I3 ref= (int a,int b) -> a+b;
		
	System.out.println(ref.sum(12, 56));	
		
		
		
//		I3 ref=new C3();
//	System.out.println(ref.sum(12, 34));	
		

	}

}
