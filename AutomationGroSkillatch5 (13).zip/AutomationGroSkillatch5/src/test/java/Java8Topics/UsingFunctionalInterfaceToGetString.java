package Java8Topics;

@FunctionalInterface
interface I2
{
	public int getLength(String str);
	
}

public class UsingFunctionalInterfaceToGetString {

	public static void main(String[] args) {
		
		I2 ref= (str)-> str.length();
		
		int result= ref.getLength("Republic");
		System.out.println(result);
		

	}

}
