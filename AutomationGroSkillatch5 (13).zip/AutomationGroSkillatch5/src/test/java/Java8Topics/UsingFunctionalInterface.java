package Java8Topics;

@FunctionalInterface
interface MyInterface
{
	void test();
}


public class UsingFunctionalInterface {

	public static void main(String[] args) {
		
		
		MyInterface ref= ()-> System.out.println("Hello");
		ref.test();
		
		
		

	}

}
