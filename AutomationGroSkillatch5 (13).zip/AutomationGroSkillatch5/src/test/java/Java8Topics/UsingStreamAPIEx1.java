package Java8Topics;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class UsingStreamAPIEx1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(13);
		li.add(22);
		li.add(32);
		li.add(16);
		li.add(19);
		
//		List<Integer> li2=new ArrayList<Integer>();
//		
//		for(Integer x:li)
//		{
//			if(x%2==0)
//			{
//				li2.add(x);
//			}
//		}
//		
//		for(int y:li2)
//		{
//			System.out.println(y);
//		}
		
	Stream<Integer> st=li.stream();	
	
	List<Integer> li2=st.filter(x-> x%2==0).collect(Collectors.toList());
		System.out.println(li2);
		
		
		

	}

}
