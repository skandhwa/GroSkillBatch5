package Java8Topics;

@FunctionalInterface
interface I4
{
	public int sum(int a,int b,int c);
	
	
	
}

//class C7 implements I4
//{
//	public int sum(int a,int b,int c)
//	{
//		int x=a+b;
//		int y=x+c;
//		return y;
//	}
//}


public class UsingFunctionalInterface3 {

	public static void main(String[] args) {
		
		I4 ref=(int a,int b,int c)->
		{
			int x=a+b;
			int y=x+c;
			return y;
		};
		
		int result=ref.sum(12,45,67);
		System.out.println(result);
		
		
		
		
		

	}

}
