package LoopingStatements;

public class ArmstrongNumberExample {

	public static void main(String[] args) {
		
		int num=153;
		int temp;
		int total=0;
		
		int x=num;
		
		while(num!=0)/// 153!=0  // 15!=0  //1!=0//0!=0
		{
			temp=num%10;//temp=153%10=3  /// temp=5 ///temp=1%10=1
			total= total + temp*temp*temp;//total= 0+27=27 /// total= 27+125=152///total= 152+1=153
			num=num/10;//num=15 // num=1//num=1/10=0
			
		}
		
		if(total==x)
		{
			System.out.println("It is an Armstrong number");
		}
		
		else
		{
			System.out.println("Not an Armstrong number");
		}
		

	}

}
