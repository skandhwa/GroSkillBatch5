package LoopingStatements;

public class NestedForLoop {

	public static void main(String[] args) {
		
		for(int i=0;i<3;i++)//i=0,1<3//1<3//2<3
		{
			for(int j=0;j<3;j++)///j=0,0<3,1<3//2<3//3<3
			{
				System.out.println(i+"  "+j);///0..0//0..1//0..2//1..0//1..1//1..2//2..0//2..1//2..2
			}
			
			
		}
		///O(n2)
		
		
		

	}

}
