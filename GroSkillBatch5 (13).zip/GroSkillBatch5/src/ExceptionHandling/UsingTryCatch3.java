package ExceptionHandling;

public class UsingTryCatch3 {

	public static void main(String[] args) {
		
		try
		{
		int a[]= {12,45,67,88};
		System.out.println(a[7]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with   "+e.getMessage());
		}
		
		int p=20,q=30;
		int r=p+q;
		System.out.println(r);
		
		

	}

}
