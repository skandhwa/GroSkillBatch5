package ExceptionHandling;

public class MultiTryCatchEx2 {

	public static void main(String[] args) {
		
		try
		{
		int a=30;
		int b=30/0;
		System.out.println(b);
		}
		
		try
		{
		String str=null;
		int x=str.length();
		System.out.println("Length of string is  "+x);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		

	}

}
