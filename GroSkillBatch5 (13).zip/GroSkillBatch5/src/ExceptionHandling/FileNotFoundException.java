package ExceptionHandling;

import java.io.File;

class Y
{
	static void test()
	{
		File f=new File("D:\\Test31stDec.txt");
		boolean flag=f.canRead();
		System.out.println(flag);
	}
}



public class FileNotFoundException {

	public static void main(String[] args) {
		
		
		

	}

}
