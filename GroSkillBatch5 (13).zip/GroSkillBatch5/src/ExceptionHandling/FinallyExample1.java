package ExceptionHandling;

public class FinallyExample1 {

	public static void main(String[] args) {
		
		try
		{
		int x=10/2;
		System.out.println(x);
		}
		
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//		}
		
		finally
		{
			System.out.println("I am finally I will always execute");
		}
		
		
		
		
		int p=10;
		int q=20;
		int r=p+q;
		System.out.println(r);
		
		
		
		
		
		

	}

}
