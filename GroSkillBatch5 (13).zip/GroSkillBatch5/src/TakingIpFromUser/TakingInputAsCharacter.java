package TakingIpFromUser;

import java.util.Scanner;

public class TakingInputAsCharacter {

	public static void main(String[] args) {
		
		System.out.println("Enter a character as input");
		
		Scanner sc=new Scanner(System.in);
		
		char ch= sc.next().charAt(0);
		
		System.out.println("The character entered by you is  "+ch);
		
		sc.close();
				
		
		

	}

}
