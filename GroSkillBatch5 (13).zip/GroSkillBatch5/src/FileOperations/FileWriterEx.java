package FileOperations;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterEx {

	public static void main(String[] args) throws IOException {
		
//		FileWriter fw=new FileWriter("D:\\FileExample\\MyTest3rdJan.txt");
//		fw.write("Java is strong language");
//		fw.close();
//		System.out.println("Adding new successfull");
//		
		
		BufferedWriter bw=new BufferedWriter(new FileWriter("D:\\FileExample\\MyTest3rdJan.txt",true));
		bw.newLine();
		bw.write("Appending Java is very strong ");
		bw.close();
		
		File f=new File("D:\\FileExample\\MyTest3rdJan.txt");
		
	boolean flag=	f.delete();
	
	System.out.println("Deleting a file  "+flag);
		
	}

}
