package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx3 {

	public static void main(String[] args) {
		
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(56);
		li.add(90);
		li.add(64);
		li.add(104);
		
		
	boolean flag=	li.contains(516);
	System.out.println(flag);
	
	li.remove(2);
	
	System.out.println(li);
	
	
	li.set(2,108);
	
	System.out.println(li);
		

	}

}
