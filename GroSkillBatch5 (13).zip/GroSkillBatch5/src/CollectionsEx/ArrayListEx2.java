package CollectionsEx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArrayListEx2 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		
		li.add(23);
		li.add(true);
		li.add(56.78f);
		li.add("Saurabh");
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("Traversing in backward direction");
		
		
		
		 ListIterator<Object> itr1 = li.listIterator(li.size());
	        while (itr1.hasPrevious()) 
	        {
	            System.out.println(itr1.previous());
	        }
		
		
		
		
		
		

	}

}
