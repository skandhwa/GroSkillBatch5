package ArrayPractice;

public class MultiDimensionalArrayEx {

	public static void main(String[] args) {
		
		int [][]a={{1,2,3},{4,5,6},{7,8,9}};
		
		int x=a.length;
		
		System.out.println("Length of array is  "+x);
		
		for(int i=0;i<x;i++)//i=0,0<3
		{
			for(int j=0;j<x;j++)//j=0,0<3//j=1,1<3
			{
				System.out.print(a[i][j]+" ");//
			}
			
			System.out.println();
		}
		
		

	}

}
