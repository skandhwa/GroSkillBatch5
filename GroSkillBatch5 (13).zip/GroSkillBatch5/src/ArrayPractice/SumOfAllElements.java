package ArrayPractice;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int []a= {6,7,9,12,14};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1,1<5//i=2,2<5
		{
			sum=sum+a[i];//sum=0+6=6//sum=6+7=13//sum=13+9
		}
		
		System.out.println("Sum of elements of arrays is   "+sum);
		

	}

}
