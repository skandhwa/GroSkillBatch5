package ArrayPractice;

public class ArrayEx1 {

	public static void main(String[] args) {
		
		int []a= {12,45,67,88,99};
		
//		int []b=new int[] {56,77,54,33,22,68,44,3,4,7};
//		
//		int []c= new int[6];
//		c[0]=12;
//		c[1]=34;
//		c[2]=62;
//		c[3]=94;
//		c[4]=112;
//		c[5]=567;
		
//		for(int i=0;i<a.length;i++)///i=0,0<5//i=1,1<5//i=2,2<5
//		{
//			System.out.println(a[i]);//a[0]///a[1]
//		}
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
