package StaticPkg;


class A10
{
static void show()
{
  System.out.println("Hello");
}

}
class B10 extends A10
{
	static void show()
{
   System.out.println("Hi");
}
	
	  void run()
	{
		super.show();
	}

}

public class STaticEx10 {

	public static void main(String[] args) {
		
		B10.show();
		A10.show();
		
		B10 obj=new B10();
		obj.run();
		

	}

}
