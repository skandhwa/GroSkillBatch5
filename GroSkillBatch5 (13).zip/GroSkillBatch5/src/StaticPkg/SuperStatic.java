package StaticPkg;

class G1
{
	 static void display()
	{
		System.out.println("Hello");
	}
	
}


class G2 extends G1
{
	static void display()
	{
		System.out.println("Hi");
	}
	
	void run()
	{
		display();
		super.display();
	}
	
}

public class SuperStatic {

	public static void main(String[] args) {
		
		G2 obj=new G2();
		obj.run();
		

	}

}
