package StringPractice;

public class StringMethods7 {

	public static void main(String[] args) {
		
		String str="apple";
	str=	str.replace('p', 'd');
	
	System.out.println("Updated String is  "+str);
	
	
	String str2="India is a democratic country";
	
	str2=str2.replaceAll("democratic","republican");
	
	System.out.println(str2);
	
	
	
	
	
	
	
		
		
		
		
	}

}
