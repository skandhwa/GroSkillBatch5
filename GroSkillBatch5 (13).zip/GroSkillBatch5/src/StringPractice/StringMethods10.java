package StringPractice;

public class StringMethods10 {

	public static void main(String[] args) {
		
		String str="Tomorrow";
	int x=	str.indexOf('o','A');
	
	System.out.println(x);
		
		

	}

}
