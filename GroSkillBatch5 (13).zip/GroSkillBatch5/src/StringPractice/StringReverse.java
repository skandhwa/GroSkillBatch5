package StringPractice;

public class StringReverse {

	public static void main(String[] args) {
		
		String str="madam";
		
		String str1=str;
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;--i)///i=2,2>=0//i=1,1>=0//i=0,0>=0//
		{
			revstr=revstr+str.charAt(i);//revstr=""+p=p//revstr=p+a=pa//revstr=pa+t=pat
		}
		System.out.println(revstr);
		
		if(str1.equalsIgnoreCase(revstr))
		{
			System.out.println("Palindrome string");
		}
		else
		{
			System.out.println("Non palindrome");
		}
		
		
		

	}

}
