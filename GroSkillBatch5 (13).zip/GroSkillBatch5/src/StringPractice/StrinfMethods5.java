package StringPractice;

public class StrinfMethods5 {

	public static void main(String[] args) {
		
		String str="India is a republican country";
		
//	String []s1=	str.split(" ");
//	
//	System.out.println(s1[2]);
//	
//	int x=s1[0].length();
//	System.out.println(x);
		
		String str1="India#nation@test&%123";

	String[]str2=str1.split("&");
		
		System.out.println(str2[1]);
		
		

	}

}
