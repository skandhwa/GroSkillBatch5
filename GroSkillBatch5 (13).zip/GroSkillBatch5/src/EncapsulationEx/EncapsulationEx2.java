package EncapsulationEx;

class Person2
{
	private int id=1234;
	private String name="Matt";
	
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	
	
	
	
}


public class EncapsulationEx2 {

	public static void main(String[] args) {
		
		
		Person2 obj=new Person2();
	System.out.println(obj.getId());	;
		
	System.out.println	(obj.getName());
		
		

	}

}
