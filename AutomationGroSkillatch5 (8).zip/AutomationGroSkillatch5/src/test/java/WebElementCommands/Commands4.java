package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Commands4 {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/dynamic_controls");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@type='text']"));
		
	if(ele.isEnabled()==true)
	{
		
		ele.sendKeys("Saurabh");
	}
		
	else
	{
		System.out.println("Element disabled");
	}
	
	driver.findElement(By.xpath("//*[text()='Enable']")).click();
	Thread.sleep(3000);
	
	if(ele.isEnabled()==true)
	{
		System.out.println("Element is enabled");
		ele.sendKeys("Saurabh");
	}
		
	else
	{
		System.out.println("Element disabled");
	}
	

	}

}
