package BasicSeleniumCommands;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

public class TakingScreenShotSelenium {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
		TakesScreenshot scrshot= (TakesScreenshot)driver;
	File srcFile=	scrshot.getScreenshotAs(OutputType.FILE);
	File destFile=new File("E:\\TestScreenShot7thFeb\\mytest.png");
	FileUtils.copyFile(srcFile, destFile);
	System.out.println("Picture captured");
		
		

	}

}
