package HandlingWindows;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindowsEx2 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String windowId=	driver.getWindowHandle();////A
	
	  System.out.println("Window Id is  "+windowId);
      driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
      Set<String> WindowIds=  driver.getWindowHandles();////A,B
    
    System.out.println("Window ID of both windows are  "+WindowIds);
    
    Iterator<String> itr=WindowIds.iterator();///
    while(itr.hasNext())////A
    {
    	String childWindowID=itr.next();////B
    	
    	if(!windowId.equals(childWindowID))
    	{
    		driver.switchTo().window(childWindowID);
    		String title=driver.getTitle();
    		System.out.println("Title of web page is  "+title);
    		driver.findElement(By.xpath("//*[text()='Downloads']")).click();
    		driver.switchTo().window(windowId);
    	String title1=	driver.getTitle();
    	System.out.println("Title of window is  "+title1);
    	
    		
    		
    	}
    	
    }
    
    
    
    
    
    
    
    
    

	}

}
