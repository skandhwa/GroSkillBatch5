package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Commands7 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		 driver.manage().window().maximize();
	String value=	 driver.findElement(By.xpath("(//input[@type='radio'])[1]")).getAttribute("value");
		
	System.out.println("The Attribute of first checkbox is   "+value);
		

	}

}
