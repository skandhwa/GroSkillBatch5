package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Commands3 {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/disappearing_elements");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//*[text()='Gallery']"));
         
	
	
		
	if(ele.isDisplayed()==true)
         {
		     System.out.println("Element located");
        	 ele.click();
        	 
         }
         
         else
         {
        	 System.out.println("Element Not displayed");
         }
	driver.navigate().refresh();
	
	}
	

}
