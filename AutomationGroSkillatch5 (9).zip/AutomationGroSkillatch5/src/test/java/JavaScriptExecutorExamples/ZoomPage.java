package JavaScriptExecutorExamples;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZoomPage {

	public static void main(String[] args) {
		

		 WebDriver driver=new ChromeDriver();
	        
	        driver.get("https://testautomationpractice.blogspot.com/");
	        driver.manage().window().maximize();
	        JavascriptExecutor js=(JavascriptExecutor)driver;
	        js.executeScript("document.body.style.zoom='50%';");
	        
	        js.executeScript("window.open('https://www.google.com', '_blank');");
	     String title=   driver.getTitle();
	     System.out.println(title);
	     
	     js.executeScript("window.close();");
	        

	}

}
