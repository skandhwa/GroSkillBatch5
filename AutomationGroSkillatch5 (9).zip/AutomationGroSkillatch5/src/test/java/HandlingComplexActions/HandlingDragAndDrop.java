package HandlingComplexActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDragAndDrop {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Static.html");
		driver.manage().window().maximize();
	WebElement src=	driver.findElement(By.xpath("//img[@id='angular']"));
	WebElement src1=	driver.findElement(By.xpath("//img[@id='mongo']"));
	WebElement target=driver.findElement(By.xpath("//div[@id='droparea']"));
	
	Actions act=new Actions(driver);
	
	act.dragAndDrop(src, target).build().perform();
	act.dragAndDrop(src1, target).build().perform();
	
	
	

	}

}
