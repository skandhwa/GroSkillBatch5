package HandlingComplexActions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingCopyPaste {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='userName']")).sendKeys("Harry")
;
		
		driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("abcd@gmail.com");
		driver.findElement(By.xpath("//*[@id='currentAddress']")).sendKeys("ABC colony , MG marg, New Delhi 700002");
		
		Actions act=new Actions(driver);
		
		//// Select the content 
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("a");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		
		//// Copy the content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("c");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		/// Press Tab key
		act.keyDown(Keys.TAB);
		act.keyUp(Keys.TAB);
		act.build().perform();
		
		////Paste the content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("v");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		
		
		
		

	}

}
