package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgGroups2 {
	
	
	@Test(groups="sanity8")
	public void test8()
	{
		System.out.println("I am sanity test8");
	}
	
	
	
	@Test(groups="sanity9")
	public void test9()
	{
		System.out.println("I am sanity test9");
	}
	
	
	

}


