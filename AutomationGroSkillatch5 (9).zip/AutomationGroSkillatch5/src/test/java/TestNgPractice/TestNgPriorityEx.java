package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgPriorityEx {
	
	@Test(priority=4)
	public void A()
	{
		System.out.println("This is test A priority 4");//4
	}
	
	@Test(priority='B')///66
	public void B()
	{
		System.out.println("This is test B priority B ");//6
	}
	
	
	@Test(priority=0)
	public void C()
	{
		System.out.println("This is test C priority 0 ");//2
	}
	
	
	@Test(priority=-7)
	public void D()
	{
		System.out.println("This is test D priority -7 ");///1
	}
	
	
	@Test(priority=4)
	public void E()
	{
		System.out.println("This is test E priority 4");//5
	}
	
	
	@Test
	public void F()
	{
		System.out.println("This is test F priority default");///3
	}
	
	

}
