package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgDisabled {
	
	
	@Test
	public void test1()
	{
		System.out.println("I am test 1");
		
	}
	
	
	@Test(enabled=true)
	public void test2()
	{
		System.out.println("I am test 2");
		
	}
	
	
	@Test(enabled=false)
	public void test3()
	{
		System.out.println("I am test 3");
		
	}

	

	@Test
	public void test4()
	{
		System.out.println("I am test 4");
		
	}
	

}
