package BasicSeleniumCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PrintAllLinksfromPage {

	public static void main(String[] args) {
		
        WebDriver driver=new ChromeDriver();
        
        driver.get("https://demo.automationtesting.in/Register.html");
        driver.manage().window().maximize();
     List<WebElement> li=   driver.findElements(By.tagName("a"));
     
     for(int i=0;i<li.size();i++)
     {
    	 System.out.println(li.get(i).getText());
     }
     
        
        

	}

}
