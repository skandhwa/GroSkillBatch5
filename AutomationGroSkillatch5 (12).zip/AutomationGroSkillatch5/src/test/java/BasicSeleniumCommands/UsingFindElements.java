package BasicSeleniumCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UsingFindElements {

	public static void main(String[] args) {
	
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	List<WebElement> li=	driver.findElements(By.tagName("FFFFFHHHH"));
	int x=li.size();
	System.out.println(x);
	
	
	

	}

}
