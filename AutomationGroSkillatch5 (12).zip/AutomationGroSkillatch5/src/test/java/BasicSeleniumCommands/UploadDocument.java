package BasicSeleniumCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UploadDocument {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html#google_vignette");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@id='photo']"));
	
	ele.sendKeys("D:\\Test31stDec.txt");

	}

}
