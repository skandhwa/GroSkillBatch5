Feature: Registration form fill up

  Scenario: Employee Details Registration form
    Given user opens the application form
    And user enters the below details
      | firstname | lastname | address | emailaddress   |
      | saurabh   | k        | delhi   | abcd@gmail.com |
    And user selects gender
    And user selects skills   