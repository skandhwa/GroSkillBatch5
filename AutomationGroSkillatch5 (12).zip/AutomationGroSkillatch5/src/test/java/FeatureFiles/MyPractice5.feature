Feature: Search product functionality

  Background: 
    Given user opens the demo app
    And user enters the uname
    And user enters the password
    When user clicks on the login button
    Then user will be navigated to home page

@sanity
  Scenario: Validate Search product functionality with electronic items
    And user will search an electronic
    And user will add the item to the cart
    Then user will go ahead for payment

  Scenario: Validate Search product functionality with clothing items
    And user will search an clothing item
    And user will add the item to the cart
    Then user will go ahead for payment

@smoke
  Scenario: Validate Search product functionality with lifestyle items
    And user will search an lifestyle item
    And user will add the item to the cart
    Then user will go ahead for payment
