

Feature: Login functionality of the application

@regression
  Scenario: Validate login functionality with correct credentials
    Given user opens the demo app
    And user enters the uname
    And user enters the password
    When user clicks on the login button
    Then user will be navigated to home page
   # And user will validate whether he navigated to correct page
    

@smoke @sanity
  Scenario Outline: Validate login functionality with correct credentials
    Given user opens the demo app
    And user enters the uname as "<username>"
    And user enters the password as "<password>"
    When user clicks on the login button
    Then user will be navigated to home page

    Examples: 
      | username | password  |
      | abcd     | test@1234 |
      | hbgfc    | test@4567 |
      | bgfc     | test@8965 |
