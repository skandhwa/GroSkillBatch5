package HandlingDBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class CreateConnection {
	
	static Object obj=null;
	@Test
	public static Object createConnection(int x) throws SQLException
	{
		Connection con=null;
		Statement myst=null;
		ResultSet myRs=null;
		
		
	con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/mypracticeschema","root","root");
	
	myst=con.createStatement();
	
	myRs=myst.executeQuery("select *  from mypracticeschema.employees1 limit 1;");
		
	while(myRs.next())
	{
		obj=myRs.getString(x);
	}
	
	System.out.println(obj.toString());
	return obj;	
		
		
	}

}
