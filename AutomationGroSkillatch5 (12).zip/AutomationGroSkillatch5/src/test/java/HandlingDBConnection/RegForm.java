package HandlingDBConnection;

import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegForm {

	public static void main(String[] args) throws SQLException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(CreateConnection.createConnection(2).toString());
		driver.findElement(By.xpath("//textarea[@rows='3']")).sendKeys(CreateConnection.createConnection(3).toString());
		

	}

}
