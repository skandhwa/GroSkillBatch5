package HandlingWindows;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindowsEx1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String windowId=	driver.getWindowHandle();
	
	System.out.println("Window Id is  "+windowId);
      driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
      
      String windowId1=	driver.getWindowHandle();
      
      System.out.println("Window Id is  "+windowId1);
      
    Set<String> WindowIds=  driver.getWindowHandles();
    
    System.out.println("Window ID of both windows are  "+WindowIds);
    
    
    

	
		

	}

}
