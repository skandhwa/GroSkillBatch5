package MISC;

class X
{
	void display()
	{
		System.out.println("Hello");
	}
}



public class NotSingleTon {

	public static void main(String[] args) {
		
		
		X obj=new X();
		obj.display();
		
		X obj1=new X();
		obj1.display();
		

	}

}
