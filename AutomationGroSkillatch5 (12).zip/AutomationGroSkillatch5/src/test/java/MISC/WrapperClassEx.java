package MISC;

public class WrapperClassEx {

	public static void main(String[] args) {
		
		int a=10;  //// primitive data type
		
		Integer obj=a;///Autoboxing
		
		int c=obj;//Unboxing
		
		
		String x="123";
	Integer y=	Integer.parseInt(x);
		
	Integer.valueOf(x);
		
		
	}

}
