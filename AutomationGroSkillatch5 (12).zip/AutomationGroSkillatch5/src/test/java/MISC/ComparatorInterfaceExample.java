package MISC;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;



class Movie2 {
    private String name; 
    private double rating; 
    private int year;    

    public Movie2(String name, double rating, int year) 
    {
        this.name = name;
        this.rating = rating;
        this.year = year;
    }

    public String getN() 
    { 
        return name; 
    } 

    public double getR() 
    { 
        return rating; 
    } 

    public int getY() 
    { 
        return year; 
    }    
}

// Comparator to sort by rating (descending)
class Rating implements Comparator<Movie2> 
{
    public int compare(Movie2 m1, Movie2 m2) 
    {
        return Double.compare(m2.getR(), m1.getR());
    }
}

// Comparator to sort by name (ascending)
class NameCompare implements Comparator<Movie2> 
{
    public int compare(Movie2 m1, Movie2 m2)
    {
        return m1.getN().compareTo(m2.getN()); 
    }
}

class YearCompare implements Comparator<Movie2> 
{
	 public int compare(Movie2 m1, Movie2 m2) 
	    {
	        return Double.compare(m1.getY(), m2.getY());
	    }
}


// Main class 
public class ComparatorInterfaceExample {
    public static void main(String[] args) {
      
        // Create a list of movies 
        ArrayList<Movie2> m = new ArrayList<>();
        m.add(new Movie2("Force Awakens", 8.3, 2015));
        m.add(new Movie2("Star Wars", 8.7, 1977));
        m.add(new Movie2("Empire Strikes Back", 8.8, 1980));

        System.out.println();

        Collections.sort(m, new Rating());
        System.out.println("Movies sorted by rating:");
        for (Movie2 m1 : m) 
        {
            System.out.println(m1.getR() + " " + m1.getN() + " " + m1.getY());
        }
        
        System.out.println();

        Collections.sort(m, new YearCompare());
        System.out.println("Movies sorted by year:");
        for (Movie2 m1 : m) 
        {
            System.out.println(m1.getR() + " " + m1.getN() + " " + m1.getY());
        }
        
        System.out.println();

        // Sort movies by name
        Collections.sort(m, new NameCompare());
        System.out.println("\nMovies sorted by name:");
        for (Movie2 m1 : m) 
        {
            System.out.println(m1.getN() + " " + m1.getR() + " " + m1.getY());
        }
    }
}