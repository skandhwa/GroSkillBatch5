package MISC;

class SingleTon2
{
	private static SingleTon2 obj;
	
	private SingleTon2()
	{
		System.out.println("Instance created");
	}
	
	public static SingleTon2 getInstance()
	{
		if(obj==null)
		{
			obj=new SingleTon2();
		}
		
		return obj;
	}
	
	public void test()
	{
		System.out.println("I am singleton method");
	}
	
	
}





public class SingleTonEx {

	public static void main(String[] args) {
		
		SingleTon2.getInstance().test();
		

	}

}
