package HandlingComplexActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDoubleClickOperations {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//*[text()='right click me']"));
	
	Actions act=new Actions(driver);
	
	act.contextClick(ele).build().perform();
	
	driver.findElement(By.xpath("//li[@class='context-menu-item context-menu-icon context-menu-icon-edit']")).click();
	driver.switchTo().alert().accept();
	
	driver.navigate().refresh();
	
	Thread.sleep(3000);
WebElement ele2=	driver.findElement(By.xpath("//*[text()='Double-Click Me To See Alert']"));
	
	act.doubleClick(ele2).build().perform();
	
	driver.switchTo().alert().accept();
	
	
	
	
	
	

	}

}
