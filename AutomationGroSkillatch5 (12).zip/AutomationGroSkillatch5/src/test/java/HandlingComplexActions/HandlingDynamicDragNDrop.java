package HandlingComplexActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDynamicDragNDrop {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		
		driver.switchTo().frame(driver.findElement(By.xpath("//*[@src='/resources/demos/droppable/default.html']")));
		
		Thread.sleep(3000);
	WebElement src=	driver.findElement(By.xpath("//div[@id='draggable']"));
   WebElement target= driver.findElement(By.xpath("//div[@id='droppable']"));
	Actions act=new Actions(driver);
	
	act.dragAndDrop(src, target).build().perform();
	
   
   
	}

}
