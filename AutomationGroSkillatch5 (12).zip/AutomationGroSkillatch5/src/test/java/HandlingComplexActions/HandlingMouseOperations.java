package HandlingComplexActions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingMouseOperations {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		Actions act=new Actions(driver);
		
		//act.moveByOffset(0, 300).build().perform();
		
		act.moveByOffset(200, 50).build().perform();
		

	}

}
