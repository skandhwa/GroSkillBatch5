package StepDefinition18;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.*;

@RunWith(Cucumber.class)
@CucumberOptions

(
		features ="src/test/java/FeatureFiles/",
		glue= {"StepDefinition18"},
		tags = "@regression",
		dryRun=false,
		monochrome=false,
		
		
		
	
		plugin= {"pretty","html:target/HtmlReports/index.html"}
		
		
		 
		
		
		)



















public class TestRunner16 {
	
	
	
	

}
