package HandlingDropDowns;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingSingleDropdown {

	public static void main(String[] args) {
		
		 WebDriver driver=new ChromeDriver();
        
         driver.get("https://demo.automationtesting.in/Register.html");
         driver.manage().window().maximize();
         WebElement ele=  driver.findElement(By.id("Skills"));
         if(ele.isDisplayed()==true && ele.isEnabled()==true)
         {
        	 Select oselect=new Select(ele);
        	 //oselect.selectByIndex(2);
        	 
        	 //oselect.selectByVisibleText("Android");
        	 
        	 //oselect.selectByValue("AutoCAD");
        	 
        	 
        	 
         }
         
         
         
         
         
         
         
		

	}

}
