package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgCrossBrowser {
	
	public static WebDriver driver;
	
	@Parameters("browser")
	@BeforeMethod
	
	public void openBroswer(String browser)
	{
		if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
		}
		
		else if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
		}
		
		
	}
	
	
	@Test
	public void run()
	{
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		Assert.assertEquals(title, "Google");
		
	}
	
	
	@Test
	public void run2()
	{
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		Assert.assertEquals(title, "Facebook – log in or sign up");
	}
	
	

}
