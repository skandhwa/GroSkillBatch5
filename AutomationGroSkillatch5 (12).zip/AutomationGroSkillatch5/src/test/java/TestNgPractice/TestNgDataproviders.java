package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataproviders {
	
	
	WebDriver driver;
	@DataProvider(name="dp")
	public Object [][] dpmethod()
	{
		return new Object [][]
				{
			
			{"Java"}  ,{"Playwright testing"} ,{"Cypress Testing"}
			
				};
	}
	
	
	@Test(dataProvider="dp")
	
	public void searchGoogle(String x) throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
	ele.sendKeys(x);
	
		Thread.sleep(3000);
		ele.sendKeys(Keys.ENTER);
//		driver.findElement(By.xpath("(//input[@value='Google Search'])[2]")).click();
//		ele.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		driver.quit();
		
		
		
	}
	
	
	
	
	

}
