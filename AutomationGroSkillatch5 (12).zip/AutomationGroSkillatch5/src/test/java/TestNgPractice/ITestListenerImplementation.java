package TestNgPractice;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ITestListenerImplementation implements ITestListener {
	
	

	@Override
	public void onTestStart(ITestResult result) {
		
		
		System.out.println("Test started");
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		
		System.out.println("Test successfull");
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		
		 WebDriver driver = InitializeDriver.getDriver();
		 TakesScreenshot scrshot= (TakesScreenshot)driver;
			File srcFile=	scrshot.getScreenshotAs(OutputType.FILE);
			File destFile=new File("E:\\TestScreenShot7thFeb\\mytest5.png");
			try {
				FileUtils.copyFile(srcFile, destFile);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Picture captured");
			
	}
	

	
	
	

	@Override
	public void onTestSkipped(ITestResult result) {
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		
	}

	@Override
	public void onStart(ITestContext context) {
		
	}

	@Override
	public void onFinish(ITestContext context) {
		
	}
	
	
	

}
