package JavaScriptExecutorExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingScroll {

	public static void main(String[] args) throws InterruptedException {
		
WebDriver driver=new ChromeDriver();
        
        driver.get("https://demo.automationtesting.in/Register.html");
        driver.manage().window().maximize();
        
        JavascriptExecutor js=(JavascriptExecutor)driver;
        Thread.sleep(3000);
        
    WebElement ele1=    driver.findElement(By.xpath("//input[@placeholder='First Name']"));
        
    String attVal=(String)js.executeScript("return arguments[0].getAttribute('class');",ele1);
    
    System.out.println(attVal);
        
        js.executeScript("window.scrollBy(0,1000)","");
        
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,-1000)","");
        
        js.executeScript("window.close();");
        
        
        
		

	}

}
