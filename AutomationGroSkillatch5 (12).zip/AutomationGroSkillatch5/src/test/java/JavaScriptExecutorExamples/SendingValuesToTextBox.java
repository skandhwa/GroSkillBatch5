package JavaScriptExecutorExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SendingValuesToTextBox {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		 driver.get("https://demo.automationtesting.in/Register.html");
	        driver.manage().window().maximize();
	        
	        JavascriptExecutor js=(JavascriptExecutor)driver;
	        Thread.sleep(3000);
	        
	 WebElement ele1=    driver.findElement(By.xpath("//input[@placeholder='First Name']"));   
	 WebElement ele2=    driver.findElement(By.xpath("//input[@placeholder='Last Name']"));        
		js.executeScript("arguments[0].value='Saurabh',arguments[1].value='Kandhway'",ele1,ele2);
		

	}

}
