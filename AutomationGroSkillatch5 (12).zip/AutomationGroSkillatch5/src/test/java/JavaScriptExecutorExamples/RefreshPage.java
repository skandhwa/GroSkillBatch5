package JavaScriptExecutorExamples;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RefreshPage {

	public static void main(String[] args) throws InterruptedException {
		
		 WebDriver driver=new ChromeDriver();
	        
	        driver.get("https://testautomationpractice.blogspot.com/");
	        driver.manage().window().maximize();
	        JavascriptExecutor js=(JavascriptExecutor)driver;
	        Thread.sleep(3000);
	        js.executeScript("history.go(0);");
	        
	String title=     (String)js.executeScript("return document.title;");
		System.out.println("Title of page is  "+title);

	}

}
