package JavaScriptExecutorExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClickOperationUsingJavaScriptExecutor {

	public static void main(String[] args) throws InterruptedException {
		
		
		 WebDriver driver=new ChromeDriver();
	        
	        driver.get("https://testautomationpractice.blogspot.com/");
	        driver.manage().window().maximize();
	        JavascriptExecutor js=(JavascriptExecutor)driver;
	        
	        
	   WebElement ele1=driver.findElement(By.id("male"));
	   WebElement ele2=driver.findElement(By.id("sunday"));
	   js.executeScript("arguments[0].scrollIntoView(true)",ele1);
	   
	   Thread.sleep(3000);
	   js.executeScript("arguments[0].click(),arguments[1].click()",ele1,ele2);
	        
	        
	        
		

	}

}
