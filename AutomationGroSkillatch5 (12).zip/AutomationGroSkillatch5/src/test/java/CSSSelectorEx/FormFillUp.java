package CSSSelectorEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FormFillUp {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		 driver.manage().window().maximize();
 driver.findElement(By.cssSelector("[placeholder='First Name']")).sendKeys("Saurabh");
	driver.findElement(By.cssSelector("[ng-model$='ress'][rows='3']")).sendKeys("Delhi");
	
	
	
	

	}

}
