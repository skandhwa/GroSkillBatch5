package HandlingDropDowns;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingMultiSelectDropdown {

	public static void main(String[] args) {
		
WebDriver driver=new ChromeDriver();
        
        driver.get("https://www.techlistic.com/p/selenium-practice-form.html#google_vignette");
        driver.manage().window().maximize();
        WebElement ele=  driver.findElement(By.id("selenium_commands"));
        Select oselect=new Select(ele);
        if(oselect.isMultiple()==true)
        {
        	oselect.selectByIndex(1);
        	oselect.selectByIndex(2);
        	oselect.selectByIndex(3);
        }
        
       // oselect.deselectAll();
        
      //  oselect.deselectByIndex(2);
        
//        WebElement ele1=oselect.getFirstSelectedOption();
//        System.out.println(ele1.getText());
        
        
   List<WebElement> li=     oselect.getAllSelectedOptions();
   for(int i=0;i<li.size();i++)
   {
	   System.out.println(li.get(i).getText());
   }
        
        
        
        
        
        
        
        
        
		

	}

}
