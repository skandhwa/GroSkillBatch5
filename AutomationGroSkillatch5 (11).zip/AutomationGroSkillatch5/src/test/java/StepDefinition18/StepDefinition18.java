package StepDefinition18;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition18 {
	
	WebDriver driver;
	
	
	@Before
	public void beforeTest1()
	{
		System.out.println("I will run this before test1 starts");
	}
	
	

	@Before
	public void beforeTest2()
	{
		System.out.println("I will run this before test2 starts");
	}
	
	@After
	public void afterTest()
	{
		System.out.println("I will run after test");
	}
	
	
	@Before("@smoke")
	public void onlybeforeSmoke()
	{
		System.out.println("I will run only before smoke");
	}
	
	@After("@smoke")
	public void onlyAfterSmoke()
	{
		System.out.println("I will run only after smoke");
	}
	
	
	@Before("@sanity")
	public void onlybeforeSanity()
	{
		System.out.println("I will run only before sanity");
	}
	
	@After("@sanity")
	public void onlyAfterSanity()
	{
		System.out.println("I will run only after sanity");
	}
	
	
	
	
	@Given("user opens the demo app")
	public void user_opens_the_demo_app() {
		
		System.out.println("user opens the demo app");
	   
		
		
	}

	@Given("user enters the uname")
	public void user_enters_the_uname() {
		
		System.out.println("user enters uname");
	   
	}

	@Given("user enters the password")
	public void user_enters_the_password() {
		
		System.out.println("user enters pwd");
	    
	}

	@When("user clicks on the login button")
	public void user_clicks_on_the_login_button() {
		
		System.out.println("user clicks login btn");
	   
	}

	@Then("user will be navigated to home page")
	public void user_will_be_navigated_to_home_page() {
		
		System.out.println("user nav. to home page");
	    
	}
	
	
	@Given("user enters the uname as {string}")
	public void user_enters_the_uname_as(String string) {
		
		
		System.out.println("user enters uname");
		
	   
	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String string) {
		
		System.out.println("user enters pwd");
	    
	}
	
	
	@Then("user will search an electronic")
	public void user_will_search_an_electronic() {
		
		System.out.println("user searches electronic item");
	   
	}

	@Then("user will add the item to the cart")
	public void user_will_add_the_item_to_the_cart() {
		
		System.out.println("user add to cart");
	    
	}

	@Then("user will go ahead for payment")
	public void user_will_go_ahead_for_payment() {
	  
	}
	
	
	@Then("user will search an clothing item")
	public void user_will_search_an_clothing_item() {
	    
	}

	@Then("user will search an lifestyle item")
	public void user_will_search_an_lifestyle_item() {
	    
	}
	
	@Given("user opens the application form")
	public void user_opens_the_application_form() {
	   
		driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		
		
		
		
	}

	@Given("user enters the below details")
	public void user_enters_the_below_details(io.cucumber.datatable.DataTable userdata) {
	    
		List<List<String>> data= userdata.asLists(String.class);
		
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
		driver.findElement(By.xpath("//textarea[@rows=3]")).sendKeys(data.get(1).get(2));
		
		
		
		
		
	}
	
	
	@Given("user selects gender")
	public void user_selects_gender() {
	   
		
		
	}

	@Given("user selects skills")
	public void user_selects_skills() {
		
		
	    
	}
	
	

	
	

}
