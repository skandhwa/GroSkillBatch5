package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProviders2 {
	
	
	WebDriver driver;
	@DataProvider(name="dp")
	public Object [][] dpmethod()
	{
		return new Object [][]
				{
			
			{"Harry","Dsouza","Delhi"}  ,{"Sam","Dsouza","Kolkata"} ,{"Matt","Dsouza","Mumbai"}
			
				};
	}
	




@Test(dataProvider="dp")
public void regForm(String fname,String lname,String address) throws InterruptedException
{
	driver=new ChromeDriver();
	driver.get("https://demo.automationtesting.in/Register.html");
	driver.manage().window().maximize();
	driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(fname);
	driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lname);
	driver.findElement(By.xpath("//textarea[@rows=3]")).sendKeys(address);
	Thread.sleep(3000);
	driver.quit();
	
	
	
	
}

}



