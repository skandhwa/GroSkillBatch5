package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(value=TestNgPractice.ITestListenerImplementation.class)

public class UsingTestNgListener {
	
	 
	
	 WebDriver driver;

	    @Test
	    public void testFailure() {

	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://www.google.com");

	       
	        Assert.assertEquals(driver.getTitle(), "WrongTitle");
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	

}
}
