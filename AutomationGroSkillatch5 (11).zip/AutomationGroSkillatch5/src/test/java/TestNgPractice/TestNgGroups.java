package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgGroups {
	
	@Test(groups="regression")
	public void test1()
	{
		System.out.println("I am regression test1");
	}
	
	
	@Test(groups="sanity1")
	public void test2()
	{
		System.out.println("I am sanity test2");
	}
	

	@Test(groups="smoke")
	public void test3()
	{
		System.out.println("I am smoke test3");
	}
	
	
	
	@Test(groups="sanity2")
	public void test4()
	{
		System.out.println("I am sanity test4");
	}
	
	

	@Test(groups="smoke")
	public void test5()
	{
		System.out.println("I am smoke test5");
	}
	
	@Test(groups="sanity3")
	public void test6()
	{
		System.out.println("I am sanity test6");
	}
	
	

}
