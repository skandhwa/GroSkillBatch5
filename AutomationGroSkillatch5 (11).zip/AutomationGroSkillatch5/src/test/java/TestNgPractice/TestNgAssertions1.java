package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgAssertions1 {

	@Test
	public void test1()
	{
//		WebDriver driver=new ChromeDriver();
//		driver.get("https://www.google.com");
	//	String title=driver.getTitle();
		//Assert.assertEquals(title, "Google123");
		
		//Assert.assertNotEquals(title, "Google123");
		
		
		
		//Assert.assertNull(title);
		
		boolean flag=false;
		
		Assert.assertTrue(flag);
		
		int x=9/3;
		System.out.println(x);
		
		
		
		
	}
	
	
	

}
