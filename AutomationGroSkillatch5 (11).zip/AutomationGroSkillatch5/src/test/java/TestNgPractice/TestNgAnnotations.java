package TestNgPractice;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNgAnnotations {
	
	@AfterSuite
	public void afterSuite()
	{
		System.out.println("This is after suite");//7
	}
	
	@AfterMethod
	public void afterMethod()
	{
		System.out.println("This is after method");//5
	}
	
	@BeforeClass
	public void beforeclass()
	{
		System.out.println("This is before class");///2
	}
	
	@Test
	public void myTest()
	{
		System.out.println("This is test");///4
	}
	
	@AfterTest
	public void aftertest()
	{
		System.out.println("This is after test");//6
	}
	
	
	@BeforeMethod
	public void beforeMethod()
	{
		System.out.println("This is before method");//3
	}
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("This is before test");///1
	}
	
	

}
