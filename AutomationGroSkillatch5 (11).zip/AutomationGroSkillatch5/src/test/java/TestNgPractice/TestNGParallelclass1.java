package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNGParallelclass1 {
	
public WebDriver driver=new ChromeDriver();
	
	@Test
	public void testGoogle()
	{
		
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void testInstagram()
	{
		
		driver.get("https://www.instagram.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void testFacebook()
	{
		
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		
	}
	
	
	

}
