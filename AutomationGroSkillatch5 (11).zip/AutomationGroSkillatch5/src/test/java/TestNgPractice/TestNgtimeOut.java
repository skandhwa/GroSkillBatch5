package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgtimeOut {
	
	
	@Test(timeOut=10000)
	public void mytest() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		Thread.sleep(8000);
		String title=driver.getTitle();
		System.out.println(title);
		
		
		
	}
	

}
