package MISC;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class handlingCHromeOptions {

	public static void main(String[] args) {
		
		
		ChromeOptions opt=new ChromeOptions();
		//opt.addArguments("--headless=new");
		opt.addArguments("--disable-notifications");
		opt.addArguments("--incognito");
		opt.addArguments("--disable-extensions");
		//opt.addArguments("-- proxy-server=");
		opt.addArguments("--window-size=1880,1020");
		
		opt.addArguments("--ignore-certificate-errors");
		
		
		WebDriver driver=new ChromeDriver(opt);
		driver.get("https://www.google.com");
		
	System.out.println(driver.getTitle());	
		
		System.out.println("test case passed");
		
		

	}

}
