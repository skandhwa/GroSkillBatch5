package HandlingComplexActions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingPauseActions {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/menu/#");
		driver.manage().window().maximize();
		Actions act=new Actions(driver);
		WebElement ele=	driver.findElement(By.xpath("//*[text()='Main Item 2']"));
        act.clickAndHold(ele).pause(Duration.ofSeconds(5)).release().build().perform();
		

	}

}
