package TestNgListenerEx;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class UsingItestResult implements ITestListener {

	@Override
	public void onTestStart(ITestResult result) {
		
		System.out.println("My test case started");
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		
		System.out.println("My test case passed");
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		System.out.println("My Test case failed");
		System.out.println("Taking screenshot");
		
		TakesScreenshot srcshot=(TakesScreenshot)DriverInitialization.initializeDriver();
		File srcFile=srcshot.getScreenshotAs(OutputType.FILE);
		File desPath=new File("E:\\ScreenShot14thJuly\\"+ "XYZ"+"Test7.jpeg");
		try {
			FileUtils.copyFile(srcFile, desPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		
	}

	@Override
	public void onStart(ITestContext context) {
		
	}

	@Override
	public void onFinish(ITestContext context) {
		
	}
	
	
	
	
	
	

}
