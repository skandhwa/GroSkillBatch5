package HandlingAlerts;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlertsWindow {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		/// Handling Simple Alert
		
//		driver.findElement(By.xpath("//*[@class='btn btn-danger']")).click();
//		Thread.sleep(5000);
//		driver.switchTo().alert().accept();
//		System.out.println("Alert Accepted");
		
	//	driver.navigate().refresh();
		
		/// Handling Confirmation alert
		
//        driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//        driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//        driver.switchTo().alert().dismiss();
//      String message=  driver.findElement(By.xpath("//p[@id='demo']")).getText();
//		System.out.println(message);
		
		
		//// Handling Prompt Alert
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Alert alert=driver.switchTo().alert();
		Thread.sleep(3000);
		alert.sendKeys("Saurabh Trainer");
		Thread.sleep(3000);
		alert.accept();
		Thread.sleep(3000);
	   String value=	driver.findElement(By.xpath("//p[@id='demo1']")).getText();
	   System.out.println("message is  "+value);	
		

	}

}

