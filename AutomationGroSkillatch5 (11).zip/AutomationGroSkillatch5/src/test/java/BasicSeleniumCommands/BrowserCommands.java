package BasicSeleniumCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands {

	public static void main(String[] args) throws InterruptedException {

           WebDriver driver=new ChromeDriver();
           driver.get("https://www.google.com");
           driver.manage().window().maximize();
           
       String title=    driver.getTitle();
       System.out.println("title of webpage is  "+title);
       
       
     String pageSource=  driver.getPageSource();
     
     System.out.println("page source is  "+pageSource);
     
     driver.findElement(By.xpath("//a[text()='Gmail']")).click();
     
     Thread.sleep(3000);
     
    String URL=   driver.getCurrentUrl();
    
    System.out.println("URL of page is  "+URL);
           
           
           
           
           
		

	}

}
