package PayloadData;

public class Payload {
	
	public static String payloadData(String name,String jobRole)
	{
		String empData="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+jobRole+"\"\r\n"
				+ "}";
		
		return empData;
	}
	
	

}
