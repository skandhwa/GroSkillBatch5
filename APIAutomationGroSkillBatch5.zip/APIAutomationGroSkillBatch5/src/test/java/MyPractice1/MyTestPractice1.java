package MyPractice1;

import static io.restassured.RestAssured.given;

import javax.naming.TimeLimitExceededException;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class MyTestPractice1 {

	public static void main(String[] args) throws TimeLimitExceededException {
		
		RestAssured.baseURI="https://reqres.in";
		
	Response res=	given().log().all().header("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		
			
		
		.when().get("api/users").
		
		
		
		then().
		log().all().
		assertThat().
		statusCode(200).
		extract().response();
	
	
	System.out.println(res);
	
	long Time=res.getTime();
	
	if(Time>5000)
	{
		throw new  TimeLimitExceededException("Outside Time range");
	}
	
	
	
	String Response=res.asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	String lastName=js.getString("data[0].last_name");
	
	Assert.assertEquals(lastName,"Bluth");
	
	
	
	
	
	
	
	
		

	}

}
