package MyPractice1;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import PayloadData.Payload;

public class MyPostReqEx1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
String Response=		given().log().all()
.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
.headers("content-type","application/json")
		.body(Payload.payloadData("Tom","Analyst"))
		
		.when().post("api/users")
		
		.then().log().all().
		headers("Connection","keep-alive")
		.headers("Server","cloudflare").
		
		assertThat().statusCode(201)
		.extract().response().asString();


System.out.println(Response);
		
		

	}

}
