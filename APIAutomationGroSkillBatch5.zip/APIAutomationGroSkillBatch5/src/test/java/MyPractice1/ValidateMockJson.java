package MyPractice1;

import org.testng.Assert;

import MockResponses.ResponsePayload;
import io.restassured.path.json.JsonPath;

public class ValidateMockJson {

	public static void main(String[] args) {
		
		///Print No of courses returned by API

		JsonPath js=new JsonPath(ResponsePayload.mockJsonData());
	int courseSize=	js.getInt("courses.size()");
	
	System.out.println("Total Courses are "+courseSize);
	
	
	////Print Purchase Amount

        int purchaseAmount=  js.getInt("dashboard.purchaseAmount");
        System.out.println("Purchase Amount is  "+purchaseAmount);
		
     ////   Print Title of the first course
        
      String courseTitle=  js.getString("courses[0].title");
      System.out.println("Course title is  "+courseTitle);
	
      
      /// Print All course titles and their respective Prices
      System.out.println("Course Title and their respective price is  ");
      for(int i=0;i<courseSize;i++)
      {
    	  String courseTitles= js.getString("courses["+i+"].title");
    	  int price= js.getInt("courses["+i+"].price");
    	  
    	  System.out.println(courseTitles+"  "+price);
    	  
    	  
    	  
    	  
      }
      
      
      
      ////Verify if Sum of all Course prices matches with Purchase Amount
 
      int sum=0;
      System.out.println("Course price and their respective copies is  ");
      for(int i=0;i<courseSize;i++)
      {
    	  int copies= js.getInt("courses["+i+"].copies");
    	  int price= js.getInt("courses["+i+"].price");
    	  
    	  int amount=copies*price;
          sum=sum+amount;
          
          System.out.println(copies+"  "+price);
          
      }
      
      Assert.assertEquals(sum, purchaseAmount);
      
      System.out.println("All test cases passed");
      
      
		

	}

}
