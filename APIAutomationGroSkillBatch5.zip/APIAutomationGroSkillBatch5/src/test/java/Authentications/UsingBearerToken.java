package Authentications;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class UsingBearerToken {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://gorest.co.in";
		
	String Response=	given().log().all().body("{\"name\":\"Tenali Ramakrishna\", \r\n"
			+ "\"gender\":\"male\", \r\n"
			+ "\"email\":\"tenali.ramakristyrfhna@15ce.com\", \r\n"
			+ "\"status\":\"active\"}")
		.header("Authorization","Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64")
		.header("content-type","application/json")
		.when().post("public/v2/users")
		.then().log().all()
		.assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println(Response);
		
		
		
		

	}

}
