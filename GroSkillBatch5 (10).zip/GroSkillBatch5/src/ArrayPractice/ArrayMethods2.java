package ArrayPractice;

import java.util.Arrays;

public class ArrayMethods2 {

	public static void main(String[] args) {
		
		int []a= {12,56,77,99};
		
	int x=	Arrays.binarySearch(a,77);
	
	System.out.println(x);
		
	
	
		
		

	}

}
