package ArrayPractice;

public class ArrayEx2 {

	public static void main(String[] args) {
		
		String []s= {"Harry","John","Tom","Latham"};
		
		char []ch= {'A','1','*','8'};
		
		boolean []flag= {true,false};
		
		
		
		
		

	}

}
