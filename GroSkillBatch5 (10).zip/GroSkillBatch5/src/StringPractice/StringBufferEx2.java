package StringPractice;

public class StringBufferEx2 {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Hello");
		sb.insert(2,"Java");
		System.out.println(sb);
		

	}

}
