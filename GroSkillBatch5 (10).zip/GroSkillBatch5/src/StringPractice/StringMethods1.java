package StringPractice;

import java.util.Arrays;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="India";
		str=str.toLowerCase();
		
//		char ch=str.charAt(2);
//		
//		System.out.println(ch);
		
	char []ch=	str.toCharArray();
	
	for(char x:ch)
	{
		System.out.print(x+" ");
	}
		
	
	Arrays.sort(ch);
	System.out.println("After sorting");
	
	for(char x:ch)
	{
		System.out.print(x+" ");
	}
	

	}

}
