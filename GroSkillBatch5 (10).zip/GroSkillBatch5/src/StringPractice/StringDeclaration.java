package StringPractice;

public class StringDeclaration {

	public static void main(String[] args) {
		
		String str="Indian";
	str=	str.concat("nation");
		System.out.println(str);
		
		
		
		
		
	String str1=new String("Republic");
	str1.concat("Bharat");
	System.out.println(str1);
		
		

	}

}
