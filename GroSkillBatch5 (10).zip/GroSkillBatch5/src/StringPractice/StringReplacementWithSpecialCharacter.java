package StringPractice;

public class StringReplacementWithSpecialCharacter {

	public static void main(String[] args) {
		
		String str="tomorrow";
		char ch='o';
		String replacement="$";
		StringBuilder sb=new StringBuilder();
		int count=1;
		
		char []ch1=str.toCharArray();
		
		for(char x:ch1)
		{
			if(x!='o')
			{
				sb.append(x);
			}
			else
			{
				sb.append(replacement.repeat(count));
				count++;
			}
		}
		
		System.out.println(sb.toString());
		
		
		
		

	}

}
