package StringPractice;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="    Ind   ia   ";
		
		str=str.trim();
		System.out.println(str);
		
		
		str=str.replaceAll(" ","");
		System.out.println(str);
		
		

	}

}
