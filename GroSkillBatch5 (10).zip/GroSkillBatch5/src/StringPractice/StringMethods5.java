package StringPractice;

public class StringMethods5 {

	public static void main(String[] args) {
		
		
		String str="Indian Republican";
		str=str.toLowerCase();
		
	int x=	str.indexOf('a',-9);
	System.out.println("Index of n is  "+x);

	}

}
