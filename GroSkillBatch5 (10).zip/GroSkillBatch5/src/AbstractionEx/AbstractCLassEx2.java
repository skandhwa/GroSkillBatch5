package AbstractionEx;

abstract class  E3
{
	void display()
	{
		System.out.println("Hello");
	}
}

class E4 extends E3
{
	void test()
	{
		System.out.println("Hi");
	}
}


public class AbstractCLassEx2 {

	public static void main(String[] args) {
		
		E4 obj=new E4();
		obj.test();
		obj.display();
		

	}

}
