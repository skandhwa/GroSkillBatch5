package TakingIpFromUser;

import java.util.Scanner;

public class AddTwoNumbers {

	public static void main(String[] args) {
		
		System.out.println("Enter first number");
		
		Scanner sc= new Scanner(System.in);
		
		int a =sc.nextInt();
		
		System.out.println("First number enetered by you is  "+a);
		
		System.out.println("Enter second number");
        int b =sc.nextInt();
		
		System.out.println("Second number enetered by you is  "+b);
		
		
		float c=a+b;
		System.out.println("sum is  "+c);
		
		
		System.out.println("For demostration of float");
		System.out.println();
		System.out.println();
		
	System.out.println("Enter first float number");
		
		
		
		float x=sc.nextFloat();
		
		System.out.println("First number enetered by you is  "+x);
		
		System.out.println("Enter second number");
		float y=sc.nextFloat();
		
		System.out.println("Second number enetered by you is  "+y);
		
		
		float r=x+y;
		System.out.println("sum is  "+r);
		
		
		
		
		
		
		
		

	}

}
