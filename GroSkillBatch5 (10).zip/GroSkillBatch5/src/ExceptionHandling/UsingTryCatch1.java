package ExceptionHandling;

public class UsingTryCatch1 {

	public static void main(String[] args) {
		
		try
		{
		int a=30;
		int b=30/0;
		System.out.println(b);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		int p=20,q=30;
		int r=p+q;
		System.out.println(r);
		

	}

}
