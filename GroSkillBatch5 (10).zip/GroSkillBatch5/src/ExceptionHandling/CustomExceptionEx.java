package ExceptionHandling;

class InvalidAgeException extends Exception
{
	public InvalidAgeException(String message)
	{
		
		
		System.out.println(message);
	}
}

class H 
{
	public static  void validateAge(int a) throws InvalidAgeException
	{
		if(a<18)
		{
			throw new InvalidAgeException("Age not valid");
		}
		else
		{
			System.out.println("Age is valid");
		}
	}
}




public class CustomExceptionEx {

	public static void main(String[] args) throws InvalidAgeException {
		
		
		H.validateAge(13);
		

	}

}
