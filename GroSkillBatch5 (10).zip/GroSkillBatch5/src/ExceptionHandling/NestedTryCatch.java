package ExceptionHandling;

public class NestedTryCatch {

	public static void main(String[] args) {
		
		try
		{
			int x=10/2;
			System.out.println(x);
			
			
			try
			{
				String str=null;
				System.out.println(str.length());
				
				
			}
			
			
			
			
			catch(NullPointerException e)
			{
				System.out.println("caught with  "+e.getMessage());
			}
		}
		
		
		
		
		
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		int m=10,n=50;
		System.out.println(m+n);
		
		

	}

}
