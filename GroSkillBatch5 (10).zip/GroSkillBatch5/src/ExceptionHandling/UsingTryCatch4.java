package ExceptionHandling;

public class UsingTryCatch4 {

	public static void main(String[] args) {
		
		
		try
		{
		Thread t=new Thread();
		t.setPriority(45);
		}
		
		catch(IllegalArgumentException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		int p=20,q=30;
		int r=p+q;
		System.out.println(r);
		

	}

}
