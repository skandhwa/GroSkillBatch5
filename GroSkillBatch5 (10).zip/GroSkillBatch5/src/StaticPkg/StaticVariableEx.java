package StaticPkg;

class T5
{
	int id;
	static String comName="TCS";
	String empName;
	
	T5(int i,String e)
	{
		id=i;
		empName=e;
		
	}
	
	
	static void change()
	{
		 comName="CTS";
	}
	
	void display()
	{
		System.out.println(id+"  "+comName+ "  "+empName);
	}
	
}


public class StaticVariableEx {

	public static void main(String[] args) {
		
		
		T5.change();
		T5 obj=new T5(1234,"Samir");
		
		obj.display();
		T5 obj1=new T5(3234,"Manish");
		obj1.display();
		T5 obj2=new T5(9865,"Ramesh");
		obj2.display();

	}

}
