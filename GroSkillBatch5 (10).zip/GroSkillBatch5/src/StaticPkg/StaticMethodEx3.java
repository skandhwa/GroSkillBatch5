package StaticPkg;

class C2
{
	static int sum(int x,int y)
	{
		return x+y;
	}
}


public class StaticMethodEx3 {

	public static void main(String[] args) {
		
	System.out.println(C2.sum(12, 45));	
		
		

	}

}
