package StringPractice;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="India";
		
	str=	str.substring(2);
	
	System.out.println(str);
		

	}

}
