package StringPractice;

public class StringBuilderEx {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Hello");
		
		sb.append("Java");
		
		System.out.println("After append value is  "+sb);
		

	}

}
