package AbstractionEx;

interface I8
{
	void shape();
	
}

interface I9 extends I8
{
	void test();
}

interface I10 extends I9
{
	void run();
}

class E11 implements I10
{
	public void shape()
	{
		System.out.println("Hi");
	}
	public void test()
	{
		System.out.println("Hello");
	}
	public void run()
	{
		System.out.println("How r u");
	}
}



public class InterfaceEx5 {

	public static void main(String[] args) {
		
		I10 ref=new E11();
		ref.shape();
		ref.test();
		ref.run();
	
	}

}
