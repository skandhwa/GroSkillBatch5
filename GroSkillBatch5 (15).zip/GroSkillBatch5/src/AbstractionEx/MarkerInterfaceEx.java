package AbstractionEx;

import java.io.Serializable;

class Person implements Serializable
{
	
}


public class MarkerInterfaceEx {

	public static void main(String[] args) {
		
		

	}

}
