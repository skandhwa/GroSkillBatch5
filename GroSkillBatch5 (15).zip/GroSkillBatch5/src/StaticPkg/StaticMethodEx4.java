package StaticPkg;

class C5
{
	 static  int x=10;
	
	 static void display()
	{
		 x=5;
		System.out.println(x);
	}
}

public class StaticMethodEx4 {
	
	static int y=10;
	
	static void test()
	{
		System.out.println("Hello");
	}

	public static void main(String[] args) {
		
	
     C5.display();
     
     System.out.println(y);
     
     StaticMethodEx4.test();
		
	}

}
