package MultiThreading;

class MyThread extends Thread
{
	public void run()
	{
		System.out.println("Thread is running");
	}
	
	
}



public class ThreadPractice1 {

	public static void main(String[] args) throws InterruptedException {
		
		MyThread obj=new MyThread();
		obj.start();
		obj.sleep(5000);
		
		
		
		

	}

}
