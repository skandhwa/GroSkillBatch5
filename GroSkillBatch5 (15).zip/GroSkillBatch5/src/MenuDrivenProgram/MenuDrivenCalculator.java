package MenuDrivenProgram;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {

          char op;
          double num1,num2,result;
          
          Scanner sc=new Scanner(System.in);
          System.out.println("Enter an operator value  : + ,-,*,/   or & to exit" );
          op=sc.next().charAt(0);
          
          System.out.println("Enter the first number");
          num1=sc.nextDouble();
          System.out.println("Enter the second number");
          num2=sc.nextDouble();
          
          switch(op)
          {
          
          case '+':
          {
        	  result=num1+num2;
        	  System.out.println("The sum of num1 and num2 is  "+result);
        	  break;
          }
          
          case '-':
          {
        	  result=num1-num2;
        	  System.out.println("The diff of num1 and num2 is  "+result);
        	  break;
          }
          
          case '*':
          {
        	  result=num1*num2;
        	  System.out.println("The product of num1 and num2 is  "+result);
        	  break;
          }
          
          case '/':
          {
        	  result=num1/num2;
        	  System.out.println("The division of num1 and num2 is  "+result);
        	  break;
          }
          
          
          case '&':
          {
        	  System.exit(0);
          }
          
          default:
          {
        	  System.out.println("You have entered an invalid choice");
          }
          
          
          sc.close();
          
          
          
          }
          
          
		

	}

}
