package CollectionsEx;

import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(12);
		v.add(45);
		v.add(42);
		v.add(65);
		
		for(Integer x:v)
		{
			System.out.println(x);
		}
		
		
	}

}
