package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsEx {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(56);
		li.add(99);
		li.add(16);
		li.add(19);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
	int x=	Collections.max(li);
	System.out.println("Max element from list  "+x);
	
	int y=	Collections.min(li);
	System.out.println("Min element from list  "+y);
	
//	Collections.sort(li);
//	System.out.println("Sorted array is ");
//	System.out.println(li);
	
	
//	Collections.reverse(li);
//	System.out.println(li);
	
	
	Collections.shuffle(li);
	System.out.println(li);
	
	
	
		
		

	}

}
