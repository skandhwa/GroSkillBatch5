package CollectionsEx;

import java.util.HashSet;
import java.util.Set;

public class SetEx1 {

	public static void main(String[] args) {
		
		Set<Object> s1=new HashSet<Object>();
		
		s1.add("apple");
		s1.add(true);
		s1.add(1234);
		s1.add('A');
		s1.add(789.65f);
		s1.add(null);
		s1.add("apple");
		s1.add(null);
		
		for(Object x:s1)
		{
			System.out.println(x);
		}
		
		
		
		
		

	}

}
