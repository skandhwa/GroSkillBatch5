package CollectionsEx;

import java.util.TreeMap;

public class TreeMapMethods2 {

	public static void main(String[] args) {
		
		TreeMap<Integer,Character>mp=new TreeMap<Integer,Character>();
		mp.put(1,'A');
		mp.put(3,'B');
		mp.put(5,'C');
		mp.put(7,'D');
		mp.put(9,'E');
		
	System.out.println(mp.ceilingEntry(6));	
	
	System.out.println(mp.firstEntry());
	
	System.out.println(mp.lastEntry());
	
	System.out.println(mp.lastKey());
	
	System.out.println(mp.lowerKey(4));
		

	}

}
