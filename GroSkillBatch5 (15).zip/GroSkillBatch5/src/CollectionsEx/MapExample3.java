package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapExample3 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(12,"apple");
		mp.put(42,"banana");
		mp.put(78,"melon");
		mp.put(112,"guava");
		
		Map<Integer,String> mp2=new LinkedHashMap<Integer,String>();
		mp2.put(12,"kiwi");
		mp2.put(42,"pineapple");
		mp2.put(18,"orange");
		mp2.put(63,"mango");
		
		
		mp.putAll(mp2);
		
		System.out.println(mp);
		
		
		mp.replace(63,"strawberries");
		
		
		System.out.println(mp);
		
		mp.clear();
		
		System.out.println(mp);
		
		
	boolean flag=	mp.isEmpty();
	
	System.out.println("Is the map empty "+flag);

	}

}
