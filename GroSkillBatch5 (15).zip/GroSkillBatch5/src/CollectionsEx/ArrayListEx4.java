package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx4 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("apple");
		li.add("guava");
		li.add("orange");
		li.add("grapes");
		
		List<String> li2=new ArrayList<String>();
		li2.add("mango");
		li2.add("melon");
		li2.add("orange");
		li2.add("grapes");
		
		
//		li.addAll(li2);
//		
//		System.out.println(li);
		
		
//		li.removeAll(li2);
//		System.out.println(li);
		
//		li.retainAll(li2);
//		System.out.println(li);
		
	boolean flag=	li.containsAll(li2);
	System.out.println(flag);
		
	
		
		

	}

}
