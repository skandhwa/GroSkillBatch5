package CollectionsEx;

import java.util.LinkedList;

public class LinkedListEx1 {

	public static void main(String[] args) {
		
		LinkedList<Integer>li=new LinkedList<Integer>();
		li.add(67);
		li.add(12);
		li.add(56);
		li.add(88);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
