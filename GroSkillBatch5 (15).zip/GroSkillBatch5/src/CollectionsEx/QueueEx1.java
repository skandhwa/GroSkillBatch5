package CollectionsEx;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx1 {

	public static void main(String[] args) {
		
		Queue<String> q1=new PriorityQueue<String>();
		q1.add("apple");
		q1.add("banana");
		q1.add("melon");
		q1.add("orange");
		
		System.out.println(q1);
		
		
		q1.remove();
		
		System.out.println(q1);
		
		
		
		
		

	}

}
