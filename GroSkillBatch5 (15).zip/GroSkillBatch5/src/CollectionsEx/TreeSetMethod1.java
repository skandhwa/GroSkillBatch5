package CollectionsEx;

import java.util.TreeSet;

public class TreeSetMethod1 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(45);
		s1.add(130);
		s1.add(16);
		s1.add(78);
		s1.add(198);
		
		
		
	int x=	s1.ceiling(70);
	
	System.out.println(x);
	
int y=	s1.floor(68);

System.out.println(y);

int z=s1.pollFirst();
System.out.println(z);


int k=s1.pollLast();

System.out.println(k);



		
		

	}

}
