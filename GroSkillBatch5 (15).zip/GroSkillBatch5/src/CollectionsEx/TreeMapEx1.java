package CollectionsEx;

import java.util.TreeMap;

public class TreeMapEx1 {

	public static void main(String[] args) {
		
		TreeMap<Integer,String>mp=new TreeMap<Integer,String>();
		mp.put(12,"apple");
		mp.put(14,"banana");
		mp.put(4,"orange");
		mp.put(1,"kiwi");
		mp.put(null,"pines");
		
		
		System.out.println(mp);
		
		System.out.println(mp.descendingMap());
		
		

	}

}
