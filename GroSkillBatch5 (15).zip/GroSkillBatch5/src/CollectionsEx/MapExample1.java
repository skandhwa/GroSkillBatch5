package CollectionsEx;

import java.util.HashMap;
import java.util.Map;

public class MapExample1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(12,"apple");
		mp.put(42,"banana");
		mp.put(78,"melon");
		mp.put(112,"guava");
		
		System.out.println(mp);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		
		
		

	}

}
