package CollectionsEx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(56);
		li.add(90);
		li.add(64);
		li.add(104);
		li.add(null);
		li.add(null);
		
		for(Integer x:li)
		{
			System.out.print(x+" ");
		}
		
		System.out.println();
		System.out.println("#######################################");
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		
		
		

	}

}
