package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx {

	public static void main(String[] args) {
		
		Map<Object,Object> mp=new LinkedHashMap<Object,Object>();
		mp.put('A',"Argentina");
		mp.put(67,'C');
		mp.put(true,765.45f);
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		

	}

}
