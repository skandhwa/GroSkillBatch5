package FileOperations;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args) throws IOException {
		
//		BufferedReader br=new BufferedReader(new FileReader("D:\\FileExample\\MyTest3rdJan.txt"));
//		String line;
//		
//		while((line=br.readLine())!=null)
//		{
//			System.out.println(line);
//		}
//		
//		br.close();
		
		
		File f=new File("D:\\FileExample\\MyTest3rdJan.txt");
		Scanner sc=new Scanner(f);
		
		while(sc.hasNextLine())
		{
			System.out.println(sc.nextLine());
		}
		
		sc.close();
		
		
		

	}

}
