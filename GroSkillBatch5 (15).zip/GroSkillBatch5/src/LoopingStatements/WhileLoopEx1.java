package LoopingStatements;

public class WhileLoopEx1 {

	public static void main(String[] args) 
	
	{
		
		int i=5;//// Assignment
		
		while(i<=8)//5<=8 ///6<=8//7<=8//8<=8///9<=8  ////condition checking
		{
			System.out.println(i);//5///6///7//8
			i++;///5++//6++///7++///8++//////increment/decrement
		}
		
		

	}

}
