package LoopingStatements;

public class FactorialNumber {

	public static void main(String[] args) {
		
		int fact=1;
		
		int num=7;
		
		for(int i=1; i<=num ;i++)///i=1, 1<=5 //i=2,2<=5//3<=5//4<=5//5<=5//6<=5
		{
			fact=fact*i;  //fact= 1*1=1//fact=1*2=2//fact=2*3=6//fact=6*4=24//fact=24*5=120
			
		}
		
		System.out.println("Factorial of number is  "+fact);
		

	}

}
