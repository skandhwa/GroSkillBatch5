package MyPkg1;

public class UnaryOperatorsEx {

	public static void main(String[] args) {
		
		int a=10;
		
		int b=20;
		
		int c= a++ + b++ + --a  + --b;
		
		// 10 + 20 + 10 + 20
		
		//a=11, b=21, 
		
		System.out.println(c);
		
		
		
		

	}

}
