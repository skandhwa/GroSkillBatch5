package ArrayPractice;

import java.util.Arrays;

public class ArrayMethods1 {

	public static void main(String[] args) {
		
		int []a= {12,556,377,99};
		
		int []b= {12,56,877,999};
		
//	boolean flag=	Arrays.equals(a,b);
//	
//	System.out.println(flag);
	
//
//			int x=Arrays.compare(a, b);
////	
//	System.out.println("Comparing two arrays  "+x);
//		
		
		Arrays.sort(a);
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
