package HandlingComplexActions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingMouseHover {

	public static void main(String[] args) {

		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/menu/#");
		driver.manage().window().maximize();
		JavascriptExecutor js=(JavascriptExecutor)driver;
        js.executeScript("document.body.style.zoom='80%';");
	WebElement ele=	driver.findElement(By.xpath("//*[text()='Main Item 2']"));

	Actions act=new Actions(driver);
	
	act.moveToElement(ele).build().perform();
	
WebElement ele2=	driver.findElement(By.xpath("//*[text()='SUB SUB LIST »']"));
	
	act.moveToElement(ele2).build().perform();
	
	
	
		

	}

}
