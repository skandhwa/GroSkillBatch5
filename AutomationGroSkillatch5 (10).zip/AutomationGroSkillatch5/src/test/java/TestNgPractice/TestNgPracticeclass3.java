package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgPracticeclass3 {
	
public WebDriver driver=new ChromeDriver();
	
	@Test
	public void testTataCliq()
	{
		
		driver.get("https://www.tatacliq.com/");
		driver.manage().window().maximize();
		
		
	}
	
	
	@Test
	public void testAjio()
	{
		
		driver.get("https://www.ajio.com");
		driver.manage().window().maximize();
		
		
	}

}
