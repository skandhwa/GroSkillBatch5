package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgPracticeclass2 {
	
	public WebDriver driver=new ChromeDriver();
	
	@Test
	public void testFlipkart()
	{
	
		driver.get("https://www.flipkart.com");
		driver.manage().window().maximize();
		
		
	}
	
	
	@Test
	public void testAmazon()
	{
		
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
		
	}

}
