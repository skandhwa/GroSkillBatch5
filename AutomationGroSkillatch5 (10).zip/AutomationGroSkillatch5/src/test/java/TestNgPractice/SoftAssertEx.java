package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertEx {
	
	@Test
	public void testGoogle()
	{
		
		SoftAssert soft=new SoftAssert();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		
		soft.assertEquals("Google123",title);
		
		int x=9/3;
		System.out.println(x);
		
		
	}
	
	

}
