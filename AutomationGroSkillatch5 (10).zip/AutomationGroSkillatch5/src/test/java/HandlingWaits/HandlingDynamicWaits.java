package HandlingWaits;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlingDynamicWaits {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();
		
		///Implicit wait
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
		///Explicit wait
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement ele=wait.until(ExpectedConditions.
				
				
				visibilityOfElementLocated(By.xpath("")));
		
		
		
		///Page load timeout
		
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
		
		
		///Fluent wait
		
		FluentWait x=new FluentWait(driver);
		x.withTimeout(Duration.ofSeconds(10));
		x.pollingEvery(Duration.ofSeconds(2));
		x.until(ExpectedConditions.visibilityOf(ele));
		x.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
		x.ignoring(NoSuchElementException.class);
		
		
		
		
		
		

	}

}

