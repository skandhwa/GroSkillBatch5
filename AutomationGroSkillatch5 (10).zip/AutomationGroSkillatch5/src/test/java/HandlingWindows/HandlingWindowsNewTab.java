package HandlingWindows;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindowsNewTab {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String windowId=	driver.getWindowHandle();
	System.out.println("Window Id is  "+windowId);
	
	driver.findElement(By.xpath("//a[@href='#Seperate']")).click();
	
	
	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	Set<String> s1= driver.getWindowHandles();
	
	System.out.println(s1);
	
	
	driver.switchTo().window("Selenium");
	

	}

}
