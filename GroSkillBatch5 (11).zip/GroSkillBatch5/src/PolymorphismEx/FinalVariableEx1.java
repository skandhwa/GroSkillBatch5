package PolymorphismEx;

class D14
{
	static final float pi=3.14f;
	
	float area()
	{
		//pi=4.55f;
		float a= pi*5*5;
		return a;
	}
	
	float area1()
	{
		float a1= pi*5*5;
		return a1;
	}
	
}


public class FinalVariableEx1 {

	public static void main(String[] args) {
		
		D14 obj=new D14();
	System.out.println(obj.area());	
		

	}

}
