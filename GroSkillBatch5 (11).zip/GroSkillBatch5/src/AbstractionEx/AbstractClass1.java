package AbstractionEx;

abstract class E1
{
	
	 int z;
	 abstract  int test();
	 abstract void run();
	 abstract void test1();
	
	void display()
	{
		System.out.println("Hello");
	}
	
	void test2()
	{
		System.out.println("Hi");
	}
}



class E2 extends E1
{
	
	int test()
	{
		int x=10;
		int y=20;
		return x+y;
	}
	
	void test1()
	{
		System.out.println("How r u");
	}
	
	void run()
	{
		System.out.println("Java");
	}
	
	
}



public class AbstractClass1 {

	public static void main(String[] args) {
		
		E1 ref=new E2();
	System.out.println(ref.test());	
	ref.display();
	ref.test1();
	ref.test2();
	ref.run();
	
		
		
		

	}

}
