package StaticPkg;

class J
{

int x,y,z;
String str;

   J(int x,int y)
{
   this.x=x;
   this.y=y;

}

J(int y,String s1)
{
this.y=y;
this.z=z;
this.x=x;

}
	
	
}



public class ConstructorEx {

	public static void main(String[] args) {
		

	}

}
