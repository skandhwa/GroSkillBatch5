package StringPractice;

import java.util.Arrays;

public class StringAnagram {

	public static void main(String[] args) {
		
		String str="Grab";
		String str1="CRAG";
		
		str=str.toLowerCase();
		str1=str1.toLowerCase();
		
		if(str.length()!=str1.length())
		{
			System.out.println("Not an Anagram");
		}
		else
		{
			char []ch=str.toCharArray();
			char []ch1=str1.toCharArray();
			
			Arrays.sort(ch);
			Arrays.sort(ch1);
			
			if(Arrays.equals(ch,ch1)==true)
			{
				System.out.println("Both Strings are anagram");
			}
			else
			{
				System.out.println("Both Strings are not anagram");
			}
			
			
		}
		
		
		
		
		
		

	}

}
