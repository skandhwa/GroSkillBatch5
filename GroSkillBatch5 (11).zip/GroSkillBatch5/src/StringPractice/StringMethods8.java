package StringPractice;

public class StringMethods8 {

	public static void main(String[] args) {
		
		String str="Indian republic , republic bharat";
		
		str=str.replaceFirst("republic","democratic");
		
		System.out.println(str);

	}

}
