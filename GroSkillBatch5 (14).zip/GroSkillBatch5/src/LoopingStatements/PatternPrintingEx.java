package LoopingStatements;

public class PatternPrintingEx {

	public static void main(String[] args) {
		
		int n=15;
		int i,j;
		
		for(i=0;i<n;i++)//i=0, 0<4//i=1,1<4 // i=2,2<=4//i=3,3<=4
		{
			for(j=0;j<=i;j++)//
			{
				System.out.print("* ");// 
			}
			
			System.out.println();
		}
		
		
		
		
		

	}

}
