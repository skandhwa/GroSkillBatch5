package StaticPkg;

public class StaticClassEx {
	
	static class C8
	{
		public void display()
		{
			System.out.println("This is a nested class");
		}
	}
	
	

	public static void main(String[] args) {
		
		
		 StaticClassEx.C8 obj = new StaticClassEx.C8();
		 obj.display();
		

	}

}
