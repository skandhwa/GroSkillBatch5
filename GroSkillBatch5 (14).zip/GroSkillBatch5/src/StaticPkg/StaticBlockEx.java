package StaticPkg;

public class StaticBlockEx {
	
	static
	{
		System.out.println("Hi");
	}
	
	static 
	{
		System.out.println("Welcome");
	}

	public static void main(String[] args) {
		
		System.out.println("Hello");
		
		
		

	}

}
