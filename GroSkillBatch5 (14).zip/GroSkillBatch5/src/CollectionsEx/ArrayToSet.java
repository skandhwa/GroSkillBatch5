package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class ArrayToSet {

	public static void main(String[] args) {
		
		int []a= {12,67,88,32,19};
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		
		for(int x:a)
		{
			s1.add(x);
		}
		
		
		System.out.println(s1);

	}

}
