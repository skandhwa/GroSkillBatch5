package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateElementFromArray {

	public static void main(String[] args) {
		
		int []a= {1,2,3,4,1,2,4,5,1,2};
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		
		for(int x:a)
		{
			s1.add(x);
		}
		
		System.out.println("Element of Set are  "+s1);
		
	Object[]arr=	s1.toArray();
	
	for(Object y:arr)
	{
		System.out.print(y+"  ");
	}
		

	}

}
