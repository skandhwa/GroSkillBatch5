package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class PrintDuplicateElement {

	public static void main(String[] args) {
		
		int []a= {1,2,3,1,1,2,4,5,1,2};
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		Set<Integer> s2=new LinkedHashSet<Integer>();
		
		for(int x:a)
		{
			if(!s1.add(x))
			{
				s2.add(x);
			}
		}
		
		System.out.println("Duplicate Elements are ");
		for(int y:s2)
		{
			System.out.print(y+"  ");
		}
		
		

	}

}
