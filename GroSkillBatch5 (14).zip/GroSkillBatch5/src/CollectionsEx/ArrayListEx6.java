package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx6 {

	public static void main(String[] args) {
		
		String []a= {"apple","mango","orange","melon"};
		
//		ArrayList<String> li=new ArrayList<>(Arrays.asList(a));
//		
//		for(String x:li)
//		{
//			System.out.println(x);
//		}
		
		List<String> li=new ArrayList<String>();
		
		for(String x:a)
		{
			li.add(x);
		}
		
		
		System.out.println(li);

	}

}
