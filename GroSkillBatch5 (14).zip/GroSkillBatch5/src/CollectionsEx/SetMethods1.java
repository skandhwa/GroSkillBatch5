package CollectionsEx;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class SetMethods1 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		
		s1.add("apple");
		s1.add("guava");
		s1.add("orange");
		s1.add("grapes");
		
	boolean flag=	s1.contains("apple");
	
	System.out.println("Does the set contains apple "+flag);
	
	s1.remove("guava");
	
	System.out.println(s1);
	
	int x=s1.size();
	System.out.println("Size of set is  "+x);
	
	s1.clear();
	
	System.out.println(s1);
	
	
	
		
		

	}

}
