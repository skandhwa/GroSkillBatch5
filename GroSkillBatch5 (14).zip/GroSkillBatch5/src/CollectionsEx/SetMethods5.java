package CollectionsEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods5 {

	public static void main(String[] args) {
		
		
		 Set<String> s1=new LinkedHashSet<String>();
			s1.add("apple");
			s1.add("guava");
//			s1.add("orange");
//			s1.add("grapes");
			
			Set<String> s2=new LinkedHashSet<String>();
			s2.add("apple");
			s2.add("guava");
			
			
		boolean flag=	s1.containsAll(s2);
		
		System.out.println(flag);
		
	boolean flag1=	s1.equals(s2);
	System.out.println(flag1);
	
			

	}

}
