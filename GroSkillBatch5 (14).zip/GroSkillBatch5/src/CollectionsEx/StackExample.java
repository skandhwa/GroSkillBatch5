package CollectionsEx;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(34);
		
		stk.push(14);
		stk.push(84);
		
		stk.push(94);
		
		
		stk.pop();
		
		System.out.println(stk);
		
		
		
		

	}

}
