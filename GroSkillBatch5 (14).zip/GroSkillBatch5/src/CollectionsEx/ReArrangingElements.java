package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReArrangingElements {

	public static void main(String[] args) {
		
		int []a= {-1,5,0,2,0,3,0,4,0};
		
		List<Integer> li=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(int x:a)
		{
			if(x!=0)
			{
			li.add(x);
			Collections.sort(li);
			}
			else
			{
				li2.add(x);
			}
			
		}
		
		li.addAll(li2);
		
		
		Object []arr=li.toArray();
		
		for(Object y:arr)
		{
			System.out.print(y+" ");
		}
		
		
		

	}

}
