package CollectionsEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapMethods1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(12,"apple");
		mp.put(42,"banana");
		mp.put(78,"melon");
		mp.put(112,"guava");
		
	boolean flag=	mp.containsKey(12);
	
	System.out.println(flag);
	
	boolean flag1=mp.containsValue("banana");
	
	System.out.println(flag1);
	
	String value=mp.get(42);
	
	System.out.println(value);
	
	mp.putIfAbsent(178, "mango");
	
	System.out.println(mp);
	
    
	
	System.out.println(mp);
	
		

	}

}
