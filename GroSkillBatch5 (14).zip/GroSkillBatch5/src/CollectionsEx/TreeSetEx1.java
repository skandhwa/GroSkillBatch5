package CollectionsEx;

import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(45);
		s1.add(130);
		s1.add(16);
		s1.add(78);
		s1.add(198);
		
		
		System.out.println(s1);
		
		System.out.println(s1.descendingSet());
		

	}

}
