package ArrayPractice;

class A15
{
public static int smallOrLarge(int []a,int total)
{
	for(int i=0;i<a.length;i++)
	{
		for(int j=i+1;j<a.length;j++)
		{
			if(a[i]>a[j])// 
			{
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	
	return a[4-1];
	}
}





public class MaximumMinimumElements {

	public static void main(String[] args) {
		
		int []a= {12,2,7,18,41};
		int x=a.length;
		System.out.println();
		
		System.out.println("Fourth smallest Element is  "+A15.smallOrLarge(a, x));
		

	}

}
