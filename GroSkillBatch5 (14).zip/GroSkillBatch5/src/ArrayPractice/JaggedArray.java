package ArrayPractice;

public class JaggedArray {

	public static void main(String[] args) {
		
		int [][]a= {{10,20,30},{40,50},{60,70,80,90}};
		
		
		
		int x=a.length;
		
		System.out.println("Length of array is  "+x);
		
		System.out.println("Jagged Array Elements are ");
		
		for(int i=0;i<x;i++)//i=0,0<3//i=1,1<3
		{
			for(int j=0;j<a[i].length;j++)//j=0,0<2
			{
				System.out.print(a[i][j]+"  ");
			}
			System.out.println();
		}
		

	}

}
