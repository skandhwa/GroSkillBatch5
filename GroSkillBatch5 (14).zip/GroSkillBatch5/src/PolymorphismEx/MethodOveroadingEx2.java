package PolymorphismEx;

class D8
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static float add(float x,int y)
	{
		return x+y;
	}
}


public class MethodOveroadingEx2 {

	public static void main(String[] args) {
		
	System.out.println(D8.add(12, 56));	
	System.out.println(D8.add(12.55f, 78));		

	}

}
