package BreakContinue;

public class BreakEx1 {

	public static void main(String[] args) {
		
		int i;
		
		for(i=1;i<=5;i++)///i=1,1<5//2<5//3<5
		{
			if(i==3)
				
			break;
			
			System.out.println(i);//1//2
			
		}
		
		
		
		

	}

}
