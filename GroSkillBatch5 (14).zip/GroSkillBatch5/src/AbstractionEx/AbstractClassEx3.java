package AbstractionEx;

abstract class E5
{
	void displayID()
	{
		System.out.println("This method displays employee ID");
	}
	
	void name()
	{
		System.out.println("This method displays employee s name");
	}
	
	abstract void salary();
	abstract void bloodGroup();
	
	
}

 class E6 extends E5
{
	void salary()
	{
		System.out.println("EMployees salary is  "+300000);
	}
	void bloodGroup()
	{
		System.out.println("EMployees blood group is  Apostivie");
	}
	
	
}
 
 class E7 extends E5
 {
	 void salary()
		{
			System.out.println("EMployees salary is  "+300000);
		}
	      void bloodGroup()
		{
			System.out.println("EMployees blood group is  Apostivie");
		}
 }



public class AbstractClassEx3 {

	public static void main(String[] args) {
		
		E5 ref=new E6();
		ref.salary();
		ref.bloodGroup();
		ref.displayID();
		ref.name();
		
		

	}

}
