package FileOperations;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {

	public static void main(String[] args) throws IOException {
		
		File f=new File("D:\\FileExample\\"+Math.random()+"Test6.xlsx");
	boolean flag=	f.createNewFile();
	System.out.println("Is the file created  "+flag);
	
	
	String name=f.getName();
	System.out.println("The name of file is  "+name);
	
	String path=f.getAbsolutePath();
	
	System.out.println("The path of file is  "+path);
	
	
	boolean flag1=f.canRead();
	System.out.println("Is the file readbale "+flag1);
	
	boolean flag2=f.canWrite();
	System.out.println("Is the file writeable "+flag2);	
		
		
		
		
	}

}
