package InheritanceExamples;

class A1
{
	void display()
	{
		System.out.println("Hello");
	}
}

class A2 extends A1
{
	void test()
	{
		System.out.println("Hi");
	}
}

public class InheritanceEx1 {

	public static void main(String[] args) {
		
		A2 obj=new A2();
		
		obj.display();
		obj.test();
		
		
		

	}

}
