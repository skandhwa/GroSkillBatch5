package StringPractice;

public class StringRegularExpressionreplacement {

	public static void main(String[] args) {
		
		String str="@#$%1234abcdABCD";
		
		str= str.replaceAll("[^A-Z]","");
		
		System.out.println(str);
		
		
		//   [a-zA-Z0-9]
		
		
		

	}

}
