package StringPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str1="ABCDD";
		
		String str2="DEF";
		
		str1=str1+str2;///ABCDDDEF
		
		int x=str1.length();//6///8
		int y=str2.length();//3
		
		//str1=str1.substring(y,x);
		
		str2=str1.substring(0,x-y);//str1.substring(0,5)
		
		 str1 = str1.substring(x - y, x);
		
		System.out.println(str1+"  "+str2);
		
		
		
		
		
		

	}

}
