package ExceptionHandling;

import java.io.File;
import java.io.FileNotFoundException;

class X
{
	public static void getFileAccess(int empID) throws FileNotFoundException
	{
		if(empID==12345)
		{
			File f=new File("D:\\Test31stDec.txt");
			boolean x=f.canRead();
			System.out.println(x);
			System.out.println("You are allowed to access");
		}
		else
		{
			System.out.println("Cannot read file");
			throw new FileNotFoundException("You are not allowed to access file");
		}
		
		}
}




public class ThrowForCheckedException {

	public static void main(String[] args) throws FileNotFoundException {
		
		
		X.getFileAccess(12345);
		
		
		
	}

}
