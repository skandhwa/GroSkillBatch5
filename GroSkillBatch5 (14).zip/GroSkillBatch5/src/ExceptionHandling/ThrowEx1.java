package ExceptionHandling;

class G
{
	public static void validateAge(int a)
	{
		if(a<18)
		{
			throw new ArithmeticException("Age not valid");
		}
		
		if(a>80)
		{
			throw new ArithmeticException("You are now too old to cast vote");
		}
		else
		{
			System.out.println("Age validated and person is elligible to vote");
		}
	}
}




public class ThrowEx1 {

	public static void main(String[] args) {
		
		G.validateAge(93);
		

	}

}
