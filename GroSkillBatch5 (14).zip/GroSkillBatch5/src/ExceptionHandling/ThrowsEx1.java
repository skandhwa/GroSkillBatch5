package ExceptionHandling;

class B
{
	static void test() throws InterruptedException
	{
		System.out.println("Hello");
		Thread.sleep(5000);
		System.out.println("Hi");
	}
}



public class ThrowsEx1 {

	public static void main(String[] args) throws InterruptedException  {
		
		System.out.println("Hello");
		
		System.out.println("Hi");
		
		B.test();
		
		
		
		
		

	}

}
