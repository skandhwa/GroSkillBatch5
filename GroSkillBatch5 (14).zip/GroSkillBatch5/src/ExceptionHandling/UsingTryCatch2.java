package ExceptionHandling;

public class UsingTryCatch2 {

	public static void main(String[] args) {
		try
		{
		String str=null;
		int x=str.length();
		System.out.println("Length of string is  "+x);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		int p=20,q=30;
		int r=p+q;
		System.out.println(r);

	}

}
