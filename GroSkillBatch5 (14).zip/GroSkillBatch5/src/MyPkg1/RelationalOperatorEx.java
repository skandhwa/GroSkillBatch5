package MyPkg1;

public class RelationalOperatorEx {

	public static void main(String[] args) {
		
		
		int a=10;///   assignment 
		
		int b= 32/3;
		
		
		System.out.println(a==b);// to check equality
		

	}

}
